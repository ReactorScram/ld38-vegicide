#include "colorado/node.h"

#include "colorado/lua-state.h"

namespace Colorado {
Node::Node () {
	numVertices = 0;
	numIndices = 0;
}

Node::~Node () {
	
}

int Node::getNumMeshes () const {
	return meshArray.size();
}

int Node::getNumObjects () const {
	return objectArray.size();
}

int Node::getNumVertices () const {
	return numVertices;
}

int Node::getNumIndices () const {
	return numIndices;
}

bool Node::loadFromBuffer (const std::vector <uchar> & buffer, bool debug) {
	unload ();
	
	LuaState l;
	
	if (! l.loadBuffer (buffer, 0, 1)) {
		return false;
	}
	else {
		loadFromLuaState (l.ls, debug);
	}
	
	return true;
}

bool Node::loadFromLuaState (lua_State * ls, bool debug) {
	if (! lua_istable (ls, -1)) {
		return false;
	}
	
	LuaState l (ls);
	
	if (l.openTable ("meshes")) {
		uint32_t numMeshes = lua_rawlen (l.ls, -1);
		
		meshArray.reserve (numMeshes);
		for (uint32_t meshIndex = 0; meshIndex < numMeshes; meshIndex++) {
			if (l.openTable (meshIndex + 1)) {
				Mesh newMesh;
				
				newMesh.loadMeshLua (l.ls, debug);
				
				meshArray.push_back (newMesh);
			}
			l.closeTable ();
		}
	}
	l.closeTable ();
	
	if (l.openTable ("objects")) {
		uint32_t numObjects = lua_rawlen (l.ls, -1);
		objectArray.reserve (numObjects);
		for (uint32_t obj_index = 0; obj_index < numObjects; obj_index++) {
			if (l.openTable (obj_index + 1)) {
				// Allocate a new SubNode
				SubNode newObj;
				
				// Load object data into the SubNode
				newObj.loadObjLua (l.ls);
				
				// Put it in the array
				objectArray.push_back (newObj);
			}
			l.closeTable ();
		}
		
		for (uint32_t obj_index = 0; obj_index < numObjects; obj_index++) {
			int parent_index = objectArray.at (obj_index).parent;
			parent_index = -1;
			
			if (parent_index == -1) {
				// Then this is at the top level, just below root
				root.addChild (&objectArray [obj_index]);
			}
			else {
				objectArray [parent_index].addChild (&objectArray [obj_index]);
			}
		}
	}
	l.closeTable ();
	
	calculateStats ();
	
	return true;
}

void Node::loadFromMesh (const Mesh & m) {
	unload ();
	
	meshArray.push_back (m);
	
	SubNode o;
	o.meshArray.push_back (0);
	
	objectArray.push_back (o);
}

void Node::unload () {
	meshArray.clear ();
	objectArray.clear ();
	
	numVertices = 0;
	numIndices = 0;
}

void Node::loadScreenQuad () {
	Mesh m;
	VboElement vertex;
	vertex.setNormal (0, 0, 1);
	vertex.matrixIndex = 0;
	
	vertex.setPos (-1, -1, 0);
	vertex.setTexCoord (0, 0);
	m.vertexArray.push_back (vertex);
	
	vertex.setPos (-1, 1, 0);
	vertex.setTexCoord (0, 1);
	m.vertexArray.push_back (vertex);
	
	vertex.setPos (1, 1, 0);
	vertex.setTexCoord (1, 1);
	m.vertexArray.push_back (vertex);
	
	vertex.setPos (1, -1, 0);
	vertex.setTexCoord (1, 0);
	m.vertexArray.push_back (vertex);
	
	std::vector <uint32_t> vertIndexArray;
	vertIndexArray.push_back (0);
	vertIndexArray.push_back (1);
	vertIndexArray.push_back (2);
	vertIndexArray.push_back (0);
	vertIndexArray.push_back (2);
	vertIndexArray.push_back (3);
	
	m.vertIndexArray = vertIndexArray;
	
	loadFromMesh (m);
}

void Node::calculateStats () {
	numVertices = 0;
	numIndices = 0;
	
	// Calculate the size of the buffers we need
	for (unsigned int j = 0; j < objectArray.size (); j++) {
		const SubNode & so = objectArray.at (j);
		for (unsigned int i = 0; i < so.meshArray.size (); ++i) {
			Mesh & currentMesh = meshArray [so.meshArray.at (i)];
			
			numVertices += currentMesh.numVerts ();
			numIndices += currentMesh.vertIndexArray.size ();
		}
	}
}
}
