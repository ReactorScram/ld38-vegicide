#include "colorado/vbo-node.h"

namespace Colorado {
VboNode::VboNode () :
	vbo (GlBuffer::VertexBuffer), ibo (GlBuffer::IndexBuffer) 
{
	numVertices = 0;
	numIndices = 0;
}

int VboNode::getObjectCount () const {
	return objectArray.size ();
}

const SubNode & VboNode::getObject (int i) const {
	return objectArray.at (i);
}

int VboNode::getNumIndices () const {
	return numIndices;
}

// NOTE: If a single mesh is used by more than one object,
// does it get duplicated? Does that screw up the vertex / 
// triangle count?
void VboNode::load (const Node & node) {
	numVertices += node.getNumVertices ();
	numIndices += node.getNumIndices ();
	
	objectArray = node.objectArray;
	
	// Allocate the buffers
	createBuffers ();
	initVbo (numVertices, numIndices);
	
	// Load data into the buffers
	int currentVboOffset = 0;
	int currentIboOffset = 0;
	
	// TODO: Make duplicate loading better
	int numObjects = node.objectArray.size ();
	for (int j = 0; j < numObjects; j++) {
		const SubNode & so = node.objectArray.at (j);
		for (unsigned int i = 0; i < so.meshArray.size (); ++i) {
			const Mesh & currentMesh = node.meshArray [so.meshArray.at (i)];
			
			loadMeshIntoVbo (currentVboOffset, currentIboOffset, j, currentMesh, so.initialMatrixIsMirrored);
			
			currentVboOffset += currentMesh.numVerts ();
			currentIboOffset += currentMesh.vertIndexArray.size ();
		}
	}
}

void VboNode::prepareVbo (const TriangleShader & s) {
	vbo.bind ();
	ibo.bind ();
	
	// TODO: Magic numbers
	// Note that the sizes and offsets here are based on how the data is represented in RAM.
	// So even though a shader may say that position is vec4 and normal is vec3, VboElement
	// can say that position is vec3 and normal is vec4, and everything will be fine.
	glVertexAttribPointer (s.vertPosAttribute, 3, GL_FLOAT, false, sizeof (VboElement), (char *)NULL + 0);
	glVertexAttribPointer (s.vertNormAttribute, 4, GL_FLOAT, false, sizeof (VboElement), (char *)NULL + sizeof (GLfloat) * 3);
	glVertexAttribPointer (s.vertMatrixIndexAttribute, 1, GL_FLOAT, false, sizeof (VboElement),(char *)NULL + sizeof (GLfloat) * 7);
	glVertexAttribPointer (s.vertTexCoordAttribute, 2, GL_FLOAT, false, sizeof (VboElement), (char *)NULL + sizeof (GLfloat) * 8);
}

void VboNode::render () const {
	glDrawElements (GL_TRIANGLES, numIndices, GL_UNSIGNED_INT, (char *)0);
}

void VboNode::render (int offset, int length) const {
	glDrawElements (GL_TRIANGLES, length, GL_UNSIGNED_INT, (char *)(0 + sizeof (GLuint) * offset));
}

void VboNode::render (TriangleShader & shader,
					  const std::vector <glm::mat4> & mvpMatrices, 
					  const std::vector <glm::mat3> & normalMatrices) const 
{
	shader.setMvpMatrices (mvpMatrices.data (), mvpMatrices.size ());
	shader.setNormalMatrices (normalMatrices.data (), normalMatrices.size ());
	
	render ();
}

void VboNode::render (const glm::mat4 & modelMatrix, const glm::mat4 & unscaledModelMatrix,
					  const NodeRenderer & renderer) const
{
	glm::mat4 modelViewMatrix = renderer.viewMatrix * modelMatrix;
	
	std::vector <glm::mat4> mvpMatrices (objectArray.size ());
	std::vector <glm::mat3> normalMatrices (objectArray.size ());
	for (uint32_t i = 0; i < objectArray.size (); ++i) {
		glm::mat4 normalMatrix = unscaledModelMatrix * objectArray.at (i).initialMatrix;
		
		normalMatrices [i] = glm::mat3 (normalMatrix);
		
		mvpMatrices [i] = modelViewMatrix * objectArray.at (i).initialMatrix;
	}
	
	render (*renderer.shader, mvpMatrices, normalMatrices);
}

void VboNode::render (const glm::mat4 & modelMatrix, const glm::mat4 & unscaledModelMatrix,
					  const NodeRenderer & renderer, const std::vector <glm::mat4> & localMatrices) const
{
	glm::mat4 modelViewMatrix = renderer.viewMatrix * modelMatrix;
	
	std::vector <glm::mat4> mvpMatrices (objectArray.size ());
	std::vector <glm::mat3> normalMatrices (objectArray.size ());
	for (uint32_t i = 0; i < objectArray.size (); ++i) {
		glm::mat4 objectMatrix = objectArray.at (i).initialMatrix * localMatrices.at (i);
		
		glm::mat4 normalMatrix = unscaledModelMatrix * objectMatrix;
		
		normalMatrices [i] = glm::mat3 (normalMatrix);
		
		mvpMatrices [i] = modelViewMatrix * objectMatrix;
	}
	
	render (*renderer.shader, mvpMatrices, normalMatrices);
}

void VboNode::createBuffers () {
	vbo.create ();
	ibo.create ();
}

void VboNode::initVbo (int numTotalVerts, int numTotalIndices) {
	vbo.bind ();
	vbo.allocate (numTotalVerts * sizeof (VboElement));
	
	ibo.bind ();
	ibo.allocate (numTotalIndices * sizeof (unsigned int));
}

void VboNode::loadMeshIntoVbo (int vboOffset, int iboOffset, int meshIndex, const Mesh & mesh,
	bool mirror)
{
	int numIndices = mesh.vertIndexArray.size ();
	
	std::vector <VboElement> verticesVector = mesh.vertexArray;
	VboElement * vertices = verticesVector.data ();
	
	for (unsigned int i = 0; i < mesh.numVerts (); i++) {
		VboElement & v = vertices [i];
		v.matrixIndex = meshIndex;
	}
	
	glBufferSubData (GL_ARRAY_BUFFER, sizeof (VboElement) * vboOffset, 
		sizeof (VboElement) * verticesVector.size (), vertices);
	
	std::vector <uint32_t> alteredIndicesVector = mesh.vertIndexArray;
	uint32_t * alteredIndices = alteredIndicesVector.data ();
	
	// Add the VBO offset to our new index data
	for (int i = 0; i < numIndices; ++i) {
		alteredIndices [i] += vboOffset;
	}
	
	// Flip the triangles around if necessary
	if (mirror) {
		for (int i = 0; i < numIndices; i += 3) {
			std::swap (alteredIndices [i + 1], alteredIndices [i + 2]);
		}
	}
	
	glBufferSubData (GL_ELEMENT_ARRAY_BUFFER, sizeof (uint32_t) * iboOffset, 
		sizeof (uint32_t) * alteredIndicesVector.size (), alteredIndices);
}
}
