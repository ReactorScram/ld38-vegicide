#include "colorado/obj-loader.h"
using namespace std;

#include "colorado/lua-state.h"
using namespace Colorado;

vector <ObjMesh> ObjMesh::loadObjFromLua (LuaState & l) {
	vector <ObjMesh> result;
	
	int32_t numMeshes = lua_rawlen (l.ls, -1);
	
	for (int32_t i = 0; i < numMeshes; i++) {
		if (l.openTable (i + 1)) {
			result.push_back (loadMeshFromLua (l));
		}
		l.closeTable ();
	}
	
	return result;
}

ObjMesh ObjMesh::loadMeshFromLua (LuaState & l) {
	ObjMesh mesh;
	
	lua_pushstring (l.ls, "name");
	lua_gettable (l.ls, -2);
	
	mesh.name = l.readString ();
	
	lua_pop (l.ls, 1);
	
	l.openTable ("attributes");
	mesh.attributes.resize (lua_rawlen (l.ls, -1));
	for (int32_t i = 0; i < (int32_t)mesh.attributes.size (); i++) {
		lua_pushinteger (l.ls, i + 1);
		lua_gettable (l.ls, -2);
		
		mesh.attributes [i] = lua_tonumber (l.ls, -1);
		
		lua_pop (l.ls, 1);
	}
	l.closeTable ();
	
	l.openTable ("indices");
	// TODO: indexed meshes
	l.closeTable ();
	
	return mesh;
}

vector <ObjMesh> ObjMesh::loadObjFromBuffer (const vector <unsigned char> & buffer) {
	LuaState l;
	l.loadFile ("obj-loader.lua", 0, 1);
	
	lua_pushstring (l.ls, "load_obj_from_buffer");
	lua_gettable (l.ls, -2);
	
	lua_pushlstring (l.ls, (const char *)buffer.data (), buffer.size ());
	l.pcall (1, 1);
	
	return loadObjFromLua (l);
}

vector <ObjMesh> ObjMesh::loadObjFromFile (string fileName) {
	LuaState l;
	l.loadFile ("obj-loader.lua", 0, 1);
	
	lua_pushstring (l.ls, "load_obj_from_file");
	lua_gettable (l.ls, -2);
	
	lua_pushlstring (l.ls, fileName.c_str (), fileName.size ());
	l.pcall (1, 1);
	
	return loadObjFromLua (l);
}
