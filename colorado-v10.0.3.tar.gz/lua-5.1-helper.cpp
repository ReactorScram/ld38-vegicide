#include "colorado/lua-5.1-helper.h"

#include "lua.hpp"

void luaL_newlibtable (lua_State * L, const luaL_Reg l []) {
	int size = 0;
	for (int i = 0; true; ++i) {
		if (l [i].name == NULL) {
			size = i - 1;
			break;
		}
	}
	
	lua_createtable (L, 0, size);
}

void luaL_setfuncs (lua_State * L, const luaL_Reg * l, int /* nup */) {
	for (int i = 0; true; ++i) {
		const luaL_Reg & reg = l [i];
		if (reg.name == NULL) {
			break;
		}
		
		lua_pushcfunction  (L, reg.func);
		lua_setfield (L, -2, reg.name);
	}
}

void luaL_setmetatable (lua_State * L, const char * tname) {
	luaL_getmetatable (L, tname);
	
	// Set the registry table's metatable
	lua_setmetatable (L, -2);
}
