#include "colorado/game-lua.h"

int main (int argc, char * argv []) {
	return Colorado::GameLua::main (argc, argv);
}
