#include "video-encoder/video-encoder-c.h"

#include "video-encoder/video-encoder.h"

typedef Colorado_VideoEncoder CVE;

static Colorado::VideoEncoder * unwrap (CVE * encoder) {
	return (Colorado::VideoEncoder *)encoder;
}

extern "C" {
CVE * Colorado_VideoEncoder_new (const char * fn, int w, int h) {
	return (CVE *)new Colorado::VideoEncoder (fn, w, h, 48000);
}

void Colorado_VideoEncoder_delete (CVE * encoder) {
	delete unwrap (encoder);
}

void Colorado_VideoEncoder_accumulateFrameFromGL (CVE * encoder) {
	unwrap (encoder)->accumulateFrameFromGL ();
}

void Colorado_VideoEncoder_captureFrameFromGL (CVE * encoder, uint8_t * frame) {
	unwrap (encoder)->captureFrameFromGL (frame);
}

void Colorado_VideoEncoder_encodeFrame (CVE * encoder, uint8_t * frame, int64_t timestamp) {
	unwrap (encoder)->encodeFrame (frame, timestamp);
}

void Colorado_VideoEncoder_encodeAccumulatedFrame (CVE * encoder, int64_t timestamp) {
	unwrap (encoder)->encodeAccumulatedFrame (timestamp);
}

void Colorado_VideoEncoder_clearAccumulator (CVE * encoder) {
	unwrap (encoder)->clearAccumulator ();
}

bool Colorado_VideoEncoder_isAvailable () {
	return Colorado::VideoEncoder::isAvailable;
}
}
