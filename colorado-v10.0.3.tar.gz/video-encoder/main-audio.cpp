#include <iostream>
using std::cerr;
using std::endl;

#include <fstream>
using std::ifstream;
using std::ofstream;

#include <string>
using std::string;

#include <vector>
using std::vector;

#include <stdint.h>

extern "C" {
	#include "x264.h"
	#include "libavformat/avformat.h"
	#include "libavutil/mathematics.h"
	#include "libswresample/swresample.h"
}

string getError (int rc) {
	vector <char> buffer;
	buffer.resize (1024, 0);
	
	av_strerror (rc, buffer.data (), buffer.size ());
	
	return string (buffer.data ());
}

typedef float Sample;

int main () {
	avcodec_register_all ();
	
	AVCodec * codec = NULL;
	AVCodecContext * c = NULL;
	
	ifstream input;
	ofstream f;
	
	codec = avcodec_find_encoder (AV_CODEC_ID_MP3);
	if (! codec) {
		cerr << "avcodec_find_encoder error" << endl;
		return 1;
	}
	
	cerr << "Codec name: " << avcodec_get_name (codec->id) << endl;
	
	cerr << "Supported sample formats:" << endl;
	for (int i = 0;; i++) {
		const AVSampleFormat fmt = codec->sample_fmts [i];
		if (fmt == 0) {
			break;
		}
		else {
			vector <char> buffer;
			buffer.resize (1024, 0);
			cerr << av_get_sample_fmt_string (buffer.data (), buffer.size (), fmt) << endl;
		}
	}
	
	c = avcodec_alloc_context3 (codec);
	
	c->sample_rate = 44100;
	c->sample_fmt = AV_SAMPLE_FMT_S16P;
	c->channels = 2;
	c->channel_layout = AV_CH_FRONT_LEFT | AV_CH_FRONT_RIGHT;
	c->codec_type = AVMEDIA_TYPE_AUDIO;
	c->bit_rate = 320 * 1000;
	
	int rc = avcodec_open2 (c, codec, NULL);
	if (rc < 0) {
		cerr << "avcodec_open2: " << getError (rc) << endl;
		return 1;
	}
	
	// In samples
	// If the frame size is 2 and it's stereo that should mean one sample each
	int frameSize = c->frame_size;
	if (frameSize == 0) {
		frameSize = 4800;
	}
	
	cerr << "frameSize: " << frameSize << endl;
	
	AVFrame * frame = av_frame_alloc ();
	
	input.open ("Magia.bin");
	f.open ("colorado.bin");
	
	bool flushingPackets = true;
	while (flushingPackets) {
		AVPacket packet;
		av_init_packet (&packet);
		
		packet.data = NULL;
		
		int gotPacket = 0;
		rc = avcodec_encode_audio2 (c, &packet, NULL, &gotPacket);
		if (rc < 0) {
			cerr << "avcodec_encode_audio2: " << getError (rc) << endl;
			return 1;
		}
		
		if (gotPacket > 0) {
			f.write ((const char *)packet.data, packet.size);
			cerr << "Flushed a packet" << endl;
		}
		else {
			flushingPackets = false;
		}
		
		av_free_packet (&packet);
	}
	
	int packetsWritten = 0;
	for (int i = 0; i < 500; i++) {
		vector <Sample> samples;
		samples.resize (frameSize, 0);
		
		input.read ((char *)samples.data (), samples.size () * sizeof (Sample));
		
		vector <Sample> planarSamples;
		
		planarSamples.resize (samples.size (), 0);
		
		for (int i = 0; i < samples.size (); i += 2) {
			planarSamples [i / 2] = samples [i];
			planarSamples [i / 2 + samples.size () / 2] = samples [i + 1];
		}
		
		frame->nb_samples = frameSize;
		
		int expectedBufferSize = av_samples_get_buffer_size (NULL, c->channels, frameSize, c->sample_fmt, 0);
		
		rc = avcodec_fill_audio_frame (frame, c->channels, c->sample_fmt, (const uint8_t *)planarSamples.data (), sizeof (Sample) * planarSamples.size (), 0);
		if (rc < 0) {
			cerr << "avcodec_fill_audio_frame: " << getError (rc) << endl;
			return 1;
		}
		
		{
			AVPacket packet;
			av_init_packet (&packet);
			
			packet.data = NULL;
			packet.size = 0;
			
			int gotPacket = 0;
			rc = avcodec_encode_audio2 (c, &packet, frame, &gotPacket);
			if (rc < 0) {
				cerr << "avcodec_encode_audio2: " << getError (rc) << endl;
				return 1;
			}
			
			if (gotPacket > 0) {
				f.write ((const char *)packet.data, packet.size);
				++packetsWritten;
			}
			
			av_free_packet (&packet);
		}
	}
	
	cerr << "Wrote " << packetsWritten << " packets" << endl;
	
	{
	bool flushingPackets = true;
		while (flushingPackets) {
			AVPacket packet;
			av_init_packet (&packet);
			
			packet.data = NULL;
			
			int gotPacket = 0;
			rc = avcodec_encode_audio2 (c, &packet, NULL, &gotPacket);
			if (rc < 0) {
				cerr << "avcodec_encode_audio2: " << getError (rc) << endl;
				return 1;
			}
			
			if (gotPacket > 0) {
				f.write ((const char *)packet.data, packet.size);
				cerr << "Flushed a packet" << endl;
			}
			else {
				flushingPackets = false;
			}
			
			av_free_packet (&packet);
		}
	}
	
	f.close ();
	input.close ();
	
	av_frame_free (&frame);
	
	avcodec_close (c);
	av_free (c);
}
