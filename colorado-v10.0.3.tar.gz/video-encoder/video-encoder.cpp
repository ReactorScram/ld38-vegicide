#include "video-encoder/video-encoder.h"

#include <iostream>
using std::cerr;
using std::endl;
#include <sstream>
#include <string>
#include <vector>

#include "colorado/gl.h"

#include "SOIL.h"

extern "C" {
	#include "x264.h"
	#include "libavformat/avformat.h"
	#include "libswscale/swscale.h"
}

namespace Colorado {

const bool VideoEncoder::isAvailable = true;

// RAII smart pointer for AVPacket
class AvPacketRaii {
public:
	AVPacket p;
	
	AvPacketRaii () {
		av_init_packet (&p);
	}

	~AvPacketRaii () {
		av_packet_unref (&p);
	}
	
	AVPacket & operator *() {
		return p;
	}
	
	AVPacket * operator -> () {
		return &p;
	}
};

class VideoEncoderPrivate {
public:
	int width, height;
	int frequency;
	
	AVPixelFormat av_pix_fmt;
	int x264_csp;
	
	SwsContext * swsContext;
	x264_t * encoder;
	x264_picture_t picIn;
	x264_picture_t picOut;
	x264_nal_t * nals;
	int nalCount;
	
	AVFormatContext * formatContext;
	AVIOContext * ioContext;
	AVStream * videoStream;
	AVStream * audioStream;
	
	// Motion blur
	std::vector <uint8_t *> blurAccumulator;
	
	std::vector <int16_t> audioBuffer;
	int64_t audioTime;
	
	VideoEncoderPrivate (const char *, int, int, int);
	~VideoEncoderPrivate ();
	
	void accumulateFrameFromGL ();
	void captureFrameFromGL (uint8_t *);
	
	void encodeFrame (uint8_t *, int64_t);
	void encodeAccumulatedFrame (int64_t);
	
	void encodeAudio (const std::vector <int16_t> &);
	
	void clearAccumulator ();
	void encodeHeaders ();
	void flushFrames ();
	
	void writeNalsToFile ();
	
	// I tried to fix the black levels by tweaking SwScale but it didn't work
	void setSwScaleColorSettings ();
};

std::string getError (int rc) {
	std::vector <char> buffer;
	buffer.resize (1024, 0);
	
	av_strerror (rc, buffer.data (), buffer.size ());
	
	return std::string (buffer.data ());
}

VideoEncoderPrivate::VideoEncoderPrivate (const char * fn, int w, int h, int freq) {
	width = w;
	height = h;
	frequency = freq;
	
	int timebaseNum = 1;
	int timebaseDen = 1000;
	
	av_pix_fmt = AV_PIX_FMT_YUV444P;
	x264_csp = X264_CSP_I444;
	
	// SWScale config
	swsContext = sws_getContext (width, height, AV_PIX_FMT_BGR32, width, height, av_pix_fmt, SWS_POINT, NULL, NULL, NULL);
	
	// X264 config
	x264_param_t param;
	if (x264_param_default_preset (&param, "ultrafast", NULL)) {
		cerr << "Failed to set default parameters" << endl;
	}
	param.i_width = width;
	param.i_height = height;
	//param.i_fps_num = 100;
	//param.i_fps_den = 1;
	param.i_timebase_num = timebaseNum;
	param.i_timebase_den = timebaseDen;
	param.i_csp = x264_csp;
	
	// Force a keyframe every 100 frames
	// This will hurt compression a little but it will make seeking and rewinding faster
	//param.i_keyint_max = 100;
	
	// Skyler from #x264 recommends this for headers or something
	// It doesn't seem to work
	//param.b_annexb = 0;
	//param.b_repeat_headers = 0;
	
	//x264_param_apply_profile (&param, "baseline");
	
	encoder = x264_encoder_open (&param);
	
	if (encoder == NULL) {
		cerr << "Couldn't open encoder" << endl;
	}
	
	if (x264_picture_alloc (&picIn, x264_csp, width, height) != 0) {
		cerr << "Couldn't allocate picIn" << endl;
	}
	
	formatContext = NULL;
	ioContext = NULL;
	
	av_register_all ();
	
	avio_open (&ioContext, fn, AVIO_FLAG_WRITE); 
	
	formatContext = avformat_alloc_context ();
	formatContext->oformat = av_guess_format (NULL, fn, NULL);
	formatContext->pb = ioContext;
	
	auto codec_id = AV_CODEC_ID_H264;
	
	videoStream = avformat_new_stream (formatContext, nullptr);
	
	videoStream->time_base.num = timebaseNum;
	videoStream->time_base.den = timebaseDen;
	
	auto video_par = videoStream->codecpar;
	video_par->codec_id = codec_id;
	video_par->codec_type = AVMEDIA_TYPE_VIDEO;
	video_par->format = av_pix_fmt;
	video_par->width = width;
	video_par->height = height;
	
	// Audio
	
	AVCodec * audioCodec = avcodec_find_encoder (AV_CODEC_ID_FLAC);
	audioStream = avformat_new_stream (formatContext, audioCodec);
	audioStream->time_base.num = 1;
	audioStream->time_base.den = 1;
	
	AVCodecContext * audioContext = audioStream->codec;
	audioContext->flags |= CODEC_FLAG_GLOBAL_HEADER;
	audioContext->sample_rate = frequency;
	audioContext->sample_fmt = AV_SAMPLE_FMT_S16;
	audioContext->channels = 2;
	audioContext->channel_layout = AV_CH_FRONT_LEFT | AV_CH_FRONT_RIGHT;
	audioContext->codec_type = AVMEDIA_TYPE_AUDIO;
	audioContext->bit_rate = 320 * 1000;
	
	/*
	FFmpeg gives a warning right here that I should be using codecpar 
	and not ->codec. 
	But if I use codecpar, the video file is not written
	so ffmpeg can go FUCK ITSELF
	*/
	int rc = avcodec_open2 (audioContext, audioCodec, NULL);
	if (rc < 0) {
		cerr << "Error avcodec_open2: " << getError (rc) << endl;
	}
	
	rc = avformat_write_header (formatContext, NULL);
	if (rc < 0) {
		cerr << "Error avformat_write_header: " << getError (rc) << endl;
	}
}

VideoEncoderPrivate::~VideoEncoderPrivate () {
	flushFrames ();
	
	av_write_trailer (formatContext);
	
	x264_picture_clean (&picIn);
	x264_encoder_close (encoder);
	
	sws_freeContext (swsContext);
	
	avcodec_close (videoStream->codec);
	//avcodec_close (audioStream->codec);
	avformat_free_context (formatContext);
	avio_close (ioContext);
}

void VideoEncoderPrivate::accumulateFrameFromGL () {
	uint8_t * videoFrame = new uint8_t [width * height * 4];
	
	captureFrameFromGL (videoFrame);
	
	blurAccumulator.push_back (videoFrame);
}

void VideoEncoderPrivate::captureFrameFromGL (uint8_t * videoFrame) {
	glReadPixels (0, 0, width, height, GL_RGBA, GL_UNSIGNED_BYTE, videoFrame);
	
	// Invert the image because OpenGL writes it upside down
	// Copied from SOIL, I assume it's fast or something
	int bytesPerPixel = 4;
	
	for (int j = 0; j * 2 < height; ++j) {
		int index1 = j * width * bytesPerPixel;
		int index2 = (height - 1 - j) * width * bytesPerPixel;
		
		for (int i = width * bytesPerPixel; i > 0; --i) {
			unsigned char temp = videoFrame [index1];
			videoFrame [index1] = videoFrame [index2];
			videoFrame [index2] = temp;
			++index1;
			++index2;
		}
	}
}

void VideoEncoderPrivate::clearAccumulator () {
	for (unsigned int i = 0; i < blurAccumulator.size (); ++i) {
		delete[] blurAccumulator [i];
	}
	blurAccumulator.clear ();
}

void VideoEncoderPrivate::encodeAccumulatedFrame (int64_t timestamp) {
	uint8_t ** inputFrames = blurAccumulator.data ();
	unsigned int numInputFrames = blurAccumulator.size ();
	
	if (numInputFrames == 0) {
		return;
	}
	else if (numInputFrames == 1) {
		encodeFrame (blurAccumulator [0], timestamp);
	}
	else {
		uint8_t * videoFrame = new uint8_t [width * height * 4];
		
		for (int i = 0; i < width * height * 4; ++i) {
			int sum = 0;
			
			for (unsigned int j = 0; j < numInputFrames; ++j) {
				sum += inputFrames [j][i];
			}
			
			videoFrame [i] = sum / numInputFrames;
		}
		
		encodeFrame (videoFrame, timestamp);
		
		delete [] videoFrame;
	}
	
	clearAccumulator ();
}

void VideoEncoderPrivate::encodeFrame (uint8_t * data, int64_t timestamp) {
	int srcstride = width * 4;
	sws_scale (swsContext, &data, &srcstride, 0, height, picIn.img.plane, picIn.img.i_stride);
	
	picIn.i_pts = timestamp;
	
	int frame_size = x264_encoder_encode (encoder, &nals, &nalCount, &picIn, &picOut);
	if (frame_size >= 0)
	{
		// I guess this means there were no errors
	}
	
	writeNalsToFile ();
}

std::vector <int16_t> makePlanar (std::vector <int16_t> samples) {
	std::vector <int16_t> planarSamples;
	
	planarSamples.resize (samples.size (), 0);
	
	for (int i = 0; i < (int)samples.size (); i += 2) {
		planarSamples [i / 2] = samples [i];
		planarSamples [i / 2 + samples.size () / 2] = samples [i + 1];
	}
	
	return planarSamples;
}

void VideoEncoderPrivate::encodeAudio (const std::vector <int16_t> & newSamples) {
	int oldSize = audioBuffer.size ();
	audioBuffer.resize (oldSize + newSamples.size (), 0);
	std::copy (newSamples.begin (), newSamples.end (), audioBuffer.begin () + oldSize);
	
	AVCodecContext * c = audioStream->codec;
	int frameSize = c->frame_size;
	int stereoFrameSize = c->frame_size * c->channels;
	
	int i = 0;
	for (; i <= (int)audioBuffer.size () - stereoFrameSize; i += stereoFrameSize) {
		AvPacketRaii packet;
		
		packet->data = NULL;
		packet->size = 0;
		
		AVFrame * frame = av_frame_alloc ();
		
		frame->nb_samples = frameSize;
		
		std::vector <int16_t> samples;
		samples.resize (stereoFrameSize);
		std::copy (audioBuffer.begin () + i, audioBuffer.begin () + i + stereoFrameSize, samples.begin ());
		
		//samples = makePlanar (samples);
		
		const uint8_t * sampleStart = (const uint8_t *)samples.data ();
		int bufferSize = sizeof (int16_t) * samples.size ();
		
		int rc = avcodec_fill_audio_frame (frame, c->channels, c->sample_fmt, sampleStart, bufferSize, 0);
		if (rc < 0) {
			cerr << "avcodec_fill_audio_frame: " << getError (rc) << endl;
		}
		
		int gotPacket = 0;
		rc = avcodec_encode_audio2 (audioStream->codec, &*packet, frame, &gotPacket);
		if (rc < 0) {
			cerr << "avcodec_encode_audio2 error: " << rc << endl;
		}
		
		packet->stream_index = audioStream->index;
		
		if (gotPacket > 0) {
			av_write_frame (formatContext, &*packet);
		}
		
		av_frame_free (&frame);
	}
	
	// Remove encoded samples from the buffer
	std::vector <int16_t> newAudioBuffer;
	int newSize = audioBuffer.size () % stereoFrameSize;
	newAudioBuffer.resize (newSize, 0);
	
	std::copy (audioBuffer.begin () + i, audioBuffer.end (), newAudioBuffer.begin ());
	
	audioBuffer = newAudioBuffer;
}

void VideoEncoderPrivate::flushFrames () {
	while (x264_encoder_delayed_frames (encoder) > 0) {
		x264_encoder_encode (encoder, &nals, &nalCount, NULL, &picOut);
		writeNalsToFile ();
	}
	
	bool flushingAudio = true;
	while (flushingAudio) {
		AvPacketRaii packet;
		
		packet->data = NULL;
		packet->stream_index = audioStream->index;
		
		int gotPacket = 0;
		int rc = avcodec_encode_audio2 (audioStream->codec, &*packet, NULL, &gotPacket);
		if (rc < 0) {
			cerr << "avcodec_encode_audio2: " << getError (rc) << endl;
		}
		
		if (gotPacket > 0) {
			av_write_frame (formatContext, &*packet);
		}
		else {
			flushingAudio = false;
		}
	}
}

void VideoEncoderPrivate::writeNalsToFile () {
	if (nalCount <= 0) {
		return;
	}
	
	AvPacketRaii packet;
	
	packet->pts = picOut.i_pts;
	packet->dts = picOut.i_dts;
	//packet.dts = picOut.i_dts;
	packet->stream_index = videoStream->index;
	if (picOut.b_keyframe > 0) {
		packet->flags = AV_PKT_FLAG_KEY;
	}
	
	// Sum up the size of all the NALs
	int size = 0;
	for (int i = 0; i < nalCount; ++i) {
		size += nals [i].i_payload;
	}
	
	// x264 guarantees that the NAL payloads will be sequential
	// I believe x264 also manages the NAL memory, so we don't have to free it
	packet->data = nals [0].p_payload; // data;
	packet->size = size;
	
	av_write_frame (formatContext, &*packet);
}

void VideoEncoderPrivate::setSwScaleColorSettings () {
	int * invTable;
	int srcRange;
	int * table;
	int dstRange;
	int brightness, contrast, saturation;
	sws_getColorspaceDetails (swsContext, &invTable, &srcRange, &table, &dstRange, &brightness, &contrast, &saturation);
	
	srcRange = 1;
	dstRange = 1;
	
	cerr << "Source range:" << srcRange << endl;
	cerr << "Dest range:" << dstRange << endl;
	
	sws_setColorspaceDetails (swsContext, invTable, srcRange, table, dstRange, brightness, contrast, saturation);
}

VideoEncoder::VideoEncoder (const char * fn, int w, int h, int freq) {
	p = new VideoEncoderPrivate (fn, w, h, freq);
}

VideoEncoder::~VideoEncoder () {
	clearAccumulator ();
	
	delete p; 
}

void VideoEncoder::accumulateFrameFromGL () {
	p->accumulateFrameFromGL ();
}

void VideoEncoder::captureFrameFromGL (uint8_t * videoFrame) {
	p->captureFrameFromGL (videoFrame);
}

void VideoEncoder::encodeFrame (uint8_t * data, int64_t timestamp) {
	p->encodeFrame (data, timestamp);
}

void VideoEncoder::encodeAccumulatedFrame (int64_t timestamp) {
	p->encodeAccumulatedFrame (timestamp);
}

void VideoEncoder::encodeAudio (const std::vector<int16_t> &b) {
	p->encodeAudio (b);
}

void VideoEncoder::clearAccumulator () {
	p->clearAccumulator ();
}
}
