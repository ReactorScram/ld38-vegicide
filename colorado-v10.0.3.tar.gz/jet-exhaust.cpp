#include "jet-exhaust.h"

#include <cmath>

JetExhaust::JetExhaust () {
	particleSpeed = 17.0 / 256.0;
	
	stringFactor = 4;
	blurFactor = 4.0;
	
	width = 0.235;
	height = 0.241;
	
	length = 1.0;
}

void JetExhaust::initialize () {
	particleStrings.resize (32);
	
	particles.resize (particleStrings.size () * stringFactor);
	
	for (int i = 0; i < particleStrings.size (); ++i) {
		JetExhaustParticle & v = particleStrings [i];
		
		qreal y = (double)qrand () / RAND_MAX * length;
		
		v.x = randomX ();
		v.y = y;
		v.z = randomZ ();
	}
	
	for (int i = 0; i < particles.size (); ++i) {
		ParticleElement & p = particles [i];
		
		p.pos.w = 64.0;
		/*
		p.color.r = 0.0625;
		p.color.g = 0.125;
		p.color.b = 1.0;
		*/
		/*
		p.color.r = 0.39583;
		p.color.g = 0.39583;
		p.color.b = 0.39583;
		*/
		p.color.r = 1.0;
		p.color.g = 0.25;
		p.color.b = 0.0625;
	}
	
	node.initVbo (particles.size ());
}

void JetExhaust::step () {
	for (int i = 0; i < particleStrings.size (); ++i) {
		JetExhaustParticle & v = particleStrings [i];
		
		v.y += particleSpeed;
		if (v.y > length) {
			v.x = randomX ();
			v.y -= length;
			v.z = randomZ ();
			v.fadeFactor = pow (v.x * v.x + v.z * v.z, 0.5f) * 4;
		}
	}
}

void JetExhaust::updateVbo () {
	int k = 0;
	for (int i = 0; i < particleStrings.size (); ++i) {
		const JetExhaustParticle & v = particleStrings.at (i);
		
		for (int j = 0; j < stringFactor; ++j, ++k) {
			ParticleElement & p = particles [k];
			p.pos.x = v.x;
			p.pos.y = v.y + blurFactor * (float)j / (float)stringFactor * particleSpeed;
			p.pos.z = v.z;
			
			p.color.a = 1.0/* - v.fadeFactor */- v.y;
		}
	}
	
	node.load (particles);
}
/*
const QVector <ParticleElement> & JetExhaust::getParticles () const {
	return particles;
}
*/

float JetExhaust::randomX () const {
	return (double)qrand () / RAND_MAX * width - width / 2.0;
}

float JetExhaust::randomZ () const {
	return (double)qrand () / RAND_MAX * height - height / 2.0;
}
