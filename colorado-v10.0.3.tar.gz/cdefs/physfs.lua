return [[

int PHYSFS_mount(const char *newDir, const char *mountPoint, int appendToPath);

]]