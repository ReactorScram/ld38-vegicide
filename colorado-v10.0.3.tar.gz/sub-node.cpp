#include "colorado/sub-node.h"
#include <iostream>
using std::cout;
using std::endl;

#include <lua.hpp>
#include "colorado/lua-5.1-helper.h"

#include <glm/glm.hpp>
using glm::vec3;
using glm::vec4;

namespace Colorado {
SubNode::SubNode () {
	
}

SubNode::~SubNode () {
	
}

void SubNode::loadObjLua (lua_State * L) {
	lua_pushstring (L, "matrix");
	lua_gettable (L, -2);
		float * matElements = &initialMatrix [0][0];
		
		for (uint32_t i = 0; i < 16; i++) {
			lua_pushinteger (L, i + 1);
			lua_gettable (L, -2);
				matElements [i] = (float)(lua_tonumber (L, -1));
			lua_pop (L, 1);
		}
	lua_pop (L, 1);
	// Transpose the matrix because my exporter writes them wrong
	initialMatrix = glm::transpose (initialMatrix);
	
	// Check if the matrix is mirrored
	vec3 x = vec3 (initialMatrix * vec4 (1, 0, 0, 0));
	vec3 y = vec3 (initialMatrix * vec4 (0, 1, 0, 0));
	vec3 z = vec3 (initialMatrix * vec4 (0, 0, 1, 0));
	
	float mirrorValue = glm::dot (glm::cross (y, x), z);
	
	initialMatrixIsMirrored = mirrorValue > 0;
	
	lua_pushstring (L, "parent");
	lua_gettable (L, -2);
		if (lua_isnumber (L, -1)) {
			int32_t fileParent = lua_tointeger (L, -1);
			if (fileParent > 0) {
				parent = fileParent - 1;
			}
		}
		else {
			parent = -1;
		}
	lua_pop (L, 1);
	
	meshArray.clear ();
	
	lua_pushstring (L, "meshes");
	lua_gettable (L, -2);
	if (lua_istable (L, -1)) {
		uint32_t numSubMeshes = lua_rawlen (L, -1);
		meshArray.resize (numSubMeshes);
		for (uint32_t i = 1; i <= numSubMeshes; i++) {
			lua_pushinteger (L, i);
			lua_gettable (L, -2);
				meshArray [i - 1] = lua_tointeger (L, -1) - 1;
			lua_pop (L, 1);
		}
	}
	lua_pop (L, 1);
}

void SubNode::addChild (SubNode * newChild) {
	children.push_back (newChild);
}
}
