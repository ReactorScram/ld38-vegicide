#define GLM_FORCE_RADIANS
#include "colorado/camera.h"

#include "colorado/plane.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_access.hpp>
#include <glm/gtc/matrix_transform.hpp>

namespace Colorado {
using glm::mat4;
using glm::vec3;
using glm::vec4;

Camera::Camera () {
	phi = glm::radians (90);
	theta = glm::radians (0);
	
	fov = 1;
	nearPlane = 1.0;
	farPlane = 1000.0;
}

void Camera::generateFrustum (float aspectRatio, Plane planes [5]) const {
	// Converts from camera space to world space
	mat4 invViewMatrix = generateInvViewMatrix ();
	
	vec3 cameraPos = vec3 (invViewMatrix * vec4 (vec3 (0.0f, 0.0f, 0.0f), 1.0f));
	
	vec4 rightNormal (vec3 (1.0f, 0.0f, fov), 0.0f);
	rightNormal = glm::normalize (rightNormal);
	
	vec4 topNormal (vec3 (0.0f, 1.0f, fov / aspectRatio), 0.0f);
	topNormal = glm::normalize (topNormal);
	
	vec4 viewSpaceNormals [5] = {
		rightNormal,
		rightNormal,
		topNormal,
		topNormal, 
		vec4 (vec3 (0.0f, 0.0f, -1.0f), 0.0f)
	};
	
	viewSpaceNormals [0].x *= -1;
	viewSpaceNormals [3].y *= -1;
	
	for (unsigned int i = 0; i < 5; ++i) {
		vec4 normal = invViewMatrix * viewSpaceNormals [i];
		planes [i].normal = vec3 (normal);
		
		if (i == 4) {
			planes [i].d = farPlane;
		}
		else {
			planes [i].setPoint (cameraPos);
		}
	}
}

mat4 Camera::generateProjectionMatrix (int width, int height) const {
	mat4 result (1.0f);
	
	float aspectRatio = (float)width / (float)height;
	
	float a = fov * nearPlane;
	float b = a / aspectRatio;
	result = glm::frustum (-a, a, -b, b, nearPlane, farPlane);
	
	return result;
}

mat4 Camera::generateInvViewMatrix () const {
	mat4 result (1.0f);
	
	result = glm::translate (result, origin);
	result = glm::rotate (result, -theta, vec3 (0.0f, 0.0f, 1.0f));
	result = glm::rotate (result, -phi, vec3 (-1.0f, 0.0f, 0.0f));
	
	result = glm::translate (result, -offset);
	
	return result;
}

mat4 Camera::generateViewMatrix () const {
	mat4 result (1.0f);
	
	result = glm::translate (result, offset);
	
	result = glm::rotate (result, phi, vec3 (-1.0f, 0.0f, 0.0f));
	result = glm::rotate (result, theta, vec3 (0, 0, 1));
	
	result = glm::translate (result, -origin);
	
	return result;
}

mat4 Camera::generateSkyViewMatrix () const {
	mat4 result (1.0f);
	
	result = glm::rotate (result, phi, vec3 (-1, 0, 0));
	result = glm::rotate (result, theta, vec3 (0, 0, 1));
	
	return result;
}

void Camera::limitPhi () {
	if (phi > 180) {
		phi = 180;
	}
	else if (phi < 0) {
		phi = 0;
	}
}

void Camera::limitTheta () {
	if (theta < 0) {
		theta += 360;
	}
	else if (theta > 360) {
		theta -= 360;
	}
}
}
