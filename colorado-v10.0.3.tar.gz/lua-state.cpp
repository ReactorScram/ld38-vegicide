#include "colorado/lua-state.h"
using std::string;
using std::vector;

#include <iostream>
using std::cerr;
using std::cout;
using std::endl;

#define LUA_OK 0

namespace Colorado {

typedef unsigned char uchar;

LuaState::LuaState () :
	ownsState (true),
	ls (nullptr)
{
	ls = luaL_newstate ();
	luaL_openlibs (ls);
}

LuaState::LuaState (lua_State * l) :
	ownsState (false),
	ls (l)
{
	
}

LuaState::~LuaState () {
	if (ownsState) {
		lua_close (ls);
	}
}

bool LuaState::loadBuffer (const vector <uchar> & buffer, int args, int results) {
	if (luaL_loadbuffer (ls, (const char *)buffer.data (), buffer.size (), 0) != 0) {
		return false;
	}
	
	return pcall (args, results) == 0;
}

bool LuaState::loadFile (const char * s, int args, int results) {
	if (luaL_loadfile (ls, s) != 0) {
		return false;
	}
	
	return pcall (args, results) == 0;
}

int LuaState::pcall (int args, int results) {
	int rc = lua_pcall (ls, args, results, 0);
	if (rc != LUA_OK) {
		cerr << "Lua error: " << lua_tostring (ls, -1) << endl;
		lua_pop (ls, 1);
	}
	
	return rc;
}

bool LuaState::openTable (const char * fieldName) {
	lua_getfield (ls, -1, fieldName);
	
	return lua_istable (ls, -1);
}

bool LuaState::openTable (int i) {
	lua_pushinteger (ls, i);
	lua_gettable (ls, -2);
	
	return lua_istable (ls, -1);
}

void LuaState::closeTable () {
	lua_pop (ls, 1);
}

void LuaState::read (const char * fieldName, bool & b) {
	lua_getfield (ls, -1, fieldName);
		b = lua_toboolean (ls, -1);
	lua_pop (ls, 1);
}

void LuaState::read (const char * fieldName, float & f) {
	lua_getfield (ls, -1, fieldName);
		f = lua_tonumber (ls, -1);
	lua_pop (ls, 1);
}

void LuaState::read (const char * fieldName, int & i) {
	lua_getfield (ls, -1, fieldName);
		i = lua_tointeger (ls, -1);
	lua_pop (ls, 1);
}

std::string LuaState::readString (int idx) {
	size_t length = 0;
	
	const char * data = lua_tolstring (ls, idx, &length);
	
	std::string result (data, length);
	
	return result;
}

std::string LuaState::readString (const char * fieldName) {
	lua_getfield (ls, -1, fieldName);
		size_t length = 0;
		
		const char * data = lua_tolstring (ls, -1, &length);
		
		std::string result (data, length);
	lua_pop (ls, 1);
	
	return result;
}

void LuaState::setTable (const char * key, bool value, int index) {
	lua_pushboolean (ls, value);
	lua_setfield (ls, index - 1, key);
}

void LuaState::setTable (const char * key, double value, int index) {
	lua_pushnumber (ls, value);
	lua_setfield (ls, index - 1, key);
}

void LuaState::setTable (const char * key, int value, int index) {
	lua_pushinteger (ls, value);
	lua_setfield (ls, index - 1, key);
}
}
