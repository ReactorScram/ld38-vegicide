#include "colorado/mesh-binder.h"

#include <iostream>

using namespace std;
using namespace Colorado;

namespace Colorado {

Mesh2::Mesh2 () {}

Mesh2::Mesh2 (const string & fn) {
	load (fn);
}

void Mesh2::load (const string & fn) {
	vector <ObjMesh> objs = ObjMesh::loadObjFromFile (fn);
	loadObjIntoVbo (objs, vbo, placements);
	
	for (auto obj: objs) {
		names.push_back (obj.name);
	}
}

VboNodePlacement Mesh2::lookupName (const string & name) const {
	for (int i = 0; i < (int)names.size (); i++) {
		if (names.at (i) == name) {
			return placements.at (i);
		}
	}
	return placements.at (0);
}

void Mesh2::renderPlacement (const VboNodePlacement & vnp) {
	glDrawArrays (GL_TRIANGLES, vnp.offset, vnp.length);
}

void Mesh2::renderPlacement (const string & s) const {
	renderPlacement (lookupName (s));
}

void Mesh2::renderPlacement (int i) const {
	renderPlacement (placements.at (i));
}

void Mesh2::loadObjIntoVbo (
	const vector <ObjMesh> & obj, 
	Colorado::Vbo & vbo, 
	vector <Colorado::VboNodePlacement> & placements) 
{
	int32_t numVertices = 0;
	
	int32_t floatsPerVertex = 6;
	
	for (auto & Mesh2: obj) {
		numVertices += Mesh2.attributes.size () / floatsPerVertex;
	}
	
	vbo.vertexBuffer.create ();
	
	vbo.vertexBuffer.bind ();
	
	vbo.vertexBuffer.allocate (numVertices * floatsPerVertex * sizeof (float));
	
	// These are vertex counts, not bytes
	int vboOffset = 0;
	
	for (auto & Mesh2: obj) {
		VboNodePlacement vnp;
		vnp.offset = vboOffset;
		
		glBufferSubData (GL_ARRAY_BUFFER, sizeof (float) * floatsPerVertex * vboOffset, 
			sizeof (float) * Mesh2.attributes.size (), Mesh2.attributes.data ());
		
		vnp.length = Mesh2.attributes.size () / floatsPerVertex;
		vboOffset += vnp.length;
		
		placements.push_back (vnp);
	}
}

void Mesh2Binder::bind (std::shared_ptr<const Mesh2> m) {
	currentMesh2 = m;
	currentMesh2->vbo.bind ();
}

void Mesh2Binder::bind (const string & code) {
	bind (getMesh2 (code));
}

void Mesh2Binder::renderPlacement (int i) const {
	currentMesh2->renderPlacement (i);
}

void Mesh2Binder::renderPlacement (const string & s) const {
	currentMesh2->renderPlacement (s);
}

shared_ptr <const Mesh2> Mesh2Binder::getMesh2 (const string & code) {
	shared_ptr <const Mesh2> result = Mesh2es [code];
	if (result) {
		return result;
	}
	else {
		cerr << "Warning: Lazy Mesh2 load - " << code << endl;
		return loadMesh2 (code);
	}
}

shared_ptr <const Mesh2> Mesh2Binder::loadMesh2 (const string & code) {
	string fn ("meshes/");
	fn.append (code);
	fn.append (".obj");
	
	shared_ptr <const Mesh2> result (new Mesh2 (fn));
	Mesh2es [code] = result;
	return result;
}

void Mesh2Binder::reloadMesh2es () {
	for (auto pair: Mesh2es) {
		loadMesh2 (pair.first);
	}
}

}
