#include <string>

namespace Colorado {
void checkGlError (const std::string &);
}
