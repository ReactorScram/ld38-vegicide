#include "colorado/lua/matrix.h"

#include "lua.hpp"

#include <glm/gtc/matrix_transform.hpp>
using glm::mat4;

#include "colorado/lua-5.1-helper.h"

namespace Colorado {

void registerColoradoMatrix (lua_State * l) {
	luaL_Reg coloradoMatrixFunctions [] = {
		{"frustum", Matrix_frustum},
		{"map", Matrix_map},
		{"rotate", Matrix_rotate},
		{"scale1", Matrix_scale1},
		{"scale", Matrix_scale3},
		{"translate", Matrix_translate},
		{NULL, NULL}
	};
	
	luaL_newmetatable (l, "ColoradoMatrix");
	luaL_newlib (l, coloradoMatrixFunctions);
	lua_setfield (l, -2, "__index");
	
	// For some reason, luaL_newlib won't add the special underscored methods
	lua_pushstring (l, "__gc");
	lua_pushcfunction (l, Matrix__gc);
	lua_settable (l, -3);
	
	lua_pushstring (l, "__mul");
	lua_pushcfunction (l, Matrix__mul);
	lua_settable (l, -3);
	
	lua_pop (l, 1);
}

mat4 * toMatrix (lua_State * l, int idx) {
	mat4 ** userData = (mat4 **)lua_touserdata (l, idx);
	return *userData;
}

void pushMatrix (lua_State * l, mat4 * m) {
	mat4 ** userData = (mat4 **)lua_newuserdata (l, sizeof (mat4 *));
	*userData = m;
	luaL_setmetatable (l, "ColoradoMatrix");
}

int Matrix_new (lua_State * l) {
	mat4 * m = new mat4 (1.0);
	pushMatrix (l, m);
	
	return 1;
}

int Matrix__gc (lua_State * l) {
	mat4 * m = toMatrix (l, 1);
	delete m;
	return 0;
}

int Matrix__mul (lua_State * l) {
	mat4 * a = toMatrix (l, 1);
	mat4 * b = toMatrix (l, 2);
	
	mat4 * result = new mat4 (*a * *b);
	pushMatrix (l, result);
	return 1;
}

int Matrix_frustum (lua_State * l) {
	mat4 * m = toMatrix (l, 1);
	double left, right, top, bottom, near, far;
	left = lua_tonumber (l, 2);
	right = lua_tonumber (l, 3);
	top = lua_tonumber (l, 4);
	bottom = lua_tonumber (l, 5);
	near = lua_tonumber (l, 6);
	far = lua_tonumber (l, 7);
	
	*m = glm::frustum (left, right, top, bottom, near, far);
	return 0;
}

int Matrix_map (lua_State * l) {
	mat4 * m = toMatrix (l, 1);
	
	float v [4];
	for (int i = 0; i < 4; ++i) {
		lua_pushinteger (l, i + 1);
		lua_gettable (l, -2);
		v [i] = lua_tonumber (l, -1);
		lua_pop (l, 1);
	}
	
	glm::vec4 vec (v [0], v [1], v[2], v [3]);
	
	vec = *m * vec;
	
	lua_newtable (l);
	
	v [0] = vec [0];
	v [1] = vec [1];
	v [2] = vec [2];
	v [3] = vec [3];
	
	for (int i = 0; i < 4; ++i) {
		lua_pushinteger (l, i + 1);
		lua_pushnumber (l, v [i]);
		lua_settable (l, -3);
	}
	return 1;
}

int Matrix_rotate (lua_State * l) {
	mat4 * m = toMatrix (l, 1);
	float angle, x, y, z;
	angle = lua_tonumber (l, 2);
	x = lua_tonumber (l, 3);
	y = lua_tonumber (l, 4);
	z = lua_tonumber (l, 5);
	
	*m = glm::rotate (*m, angle, glm::vec3 (x, y, z));
	
	return 0;
}

int Matrix_scale1 (lua_State * l) {
	mat4 * m = toMatrix (l, 1);
	float scale = lua_tonumber (l, 2);
	
	*m = glm::scale (*m, glm::vec3 (scale));
	return 0;
}

int Matrix_scale3 (lua_State * l) {
	mat4 * m = toMatrix (l, 1);
	float x, y, z;
	x = lua_tonumber (l, 2);
	y = lua_tonumber (l, 3);
	z = lua_tonumber (l, 4);
	
	*m = glm::scale (*m, glm::vec3 (x, y, z));
	return 0;
}

int Matrix_translate (lua_State * l) {
	mat4 * m = toMatrix (l, 1);
	float x, y, z;
	x = lua_tonumber (l, 2);
	y = lua_tonumber (l, 3);
	z = lua_tonumber (l, 4);
	
	*m = glm::translate (*m, glm::vec3 (x, y, z));
	return 0;
}

}
