#include "colorado/lua/lua-audio.h"

#include <iostream>
using std::cerr;
using std::endl;

#include <fstream>

#include "lua.hpp"

#include <SDL/SDL_events.h>
#include <SDL_mixer.h>

#include "colorado/lua-5.1-helper.h"
#include "colorado/lua/colorado.h"

//namespace Colorado {
//namespace Lua {

//extern "C" {
void Colorado_Lua_hookMusicFinished () {
	SDL_Event event;
	event.type = SDL_USEREVENT;
	event.user.code = 0;
	
	SDL_PushEvent (&event);
}

void Colorado_Lua_Audio_recordChunk (void * opaque, uint8_t * buffer, int bufferLen) {
	std::ofstream * stream = (std::ofstream *)opaque;
	stream->write ((const char *)buffer, bufferLen);
}

void * Colorado_Lua_Audio_startRecording (const char * fn) {
	std::ofstream * stream = new std::ofstream (fn);
	return (void *)stream;
}

void Colorado_Lua_Audio_stopRecording (void * opaque) {
	std::ofstream * stream = (std::ofstream *)opaque;
	stream->close ();
	delete stream;
}
//}

//}
//}
