#include "colorado/lua/lua-buffer.h"

#include "lua.hpp"
#include "stdint.h"

#include "colorado/lua-5.1-helper.h"

namespace Colorado {
namespace Lua {

static int Buffer_new (lua_State * l) {
	int size = lua_tointeger (l, 1);
	uint8_t * data = new uint8_t [size];
	
	lua_pushlightuserdata (l, data);
	
	return 1;
}

static int Buffer_delete (lua_State * l) {
	uint8_t * data = (uint8_t *)lua_touserdata (l, 1);
	delete[] data; 
	return 0;
}

static int Buffer_setFloats (lua_State * l) {
	uint8_t * data = (uint8_t *)lua_touserdata (l, 1);
	int byteOffset = lua_tointeger (l, 2);
	
	float * numbers = (float *)(&(data [byteOffset]));
	
	int numberCount = lua_rawlen (l, 3);
	
	for (int i = 0; i < numberCount; ++i) {
		lua_pushinteger (l, i + 1);
		lua_gettable (l, 3);
		
		numbers [i] = lua_tonumber (l, -1);
		
		lua_pop (l, 1);
	}
	
	return 0;
}

static int Buffer_setInts (lua_State * l) {
	uint8_t * data = (uint8_t *)lua_touserdata (l, 1);
	int byteOffset = lua_tointeger (l, 2);
	
	uint16_t * numbers = (uint16_t *)(&(data [byteOffset]));
	
	int numberCount = lua_rawlen (l, 3);
	
	for (int i = 0; i < numberCount; ++i) {
		lua_pushinteger (l, i + 1);
		lua_gettable (l, 3);
		
		numbers [i] = lua_tointeger (l, -1);
		
		lua_pop (l, 1);
	}
	
	return 0;
}

int registerBufferLib (lua_State * l) {
	luaL_Reg fns [] = {
	{"new", Buffer_new},
	{"delete", Buffer_delete},
	{"setFloats", Buffer_setFloats},
	{"setInts", Buffer_setInts},
	{NULL, NULL}
	};
	
	luaL_newlib (l, fns);
	
	return 1;
}

}
}
