return function (t)
	return -0.5 * math.cos (math.pi * t) + 0.5
end