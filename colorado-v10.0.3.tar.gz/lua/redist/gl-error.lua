local Gl = require "Colorado.glew-lua"

return function (...)
	--print ("GL error:", Gl.GetError (), ...)
end