#include "colorado/lua/colorado.h"

#include <vector>
using std::vector;

#include "lua.hpp"
#include "colorado/lua-5.1-helper.h"

#include <SDL/SDL.h>

#include "SOIL.h"

#include "colorado/gl.h"
#include "colorado/image-to-texture.h"

typedef unsigned char uchar;

namespace Colorado {
namespace Lua {

static int isKeyPressed (lua_State * l) {
	const Uint8 * state = (const Uint8 *)lua_touserdata (l, 1);
	Uint32 scanCode = lua_tointeger (l, 2);
	
	lua_pushboolean (l, state [scanCode]);
	return 1;
}

void registerInts (lua_State * l, KeyValueInt enums []) {
	for (int i = 0;; ++i) {
		if (enums [i].key == NULL) {
			break;
		}
		else {
			lua_pushstring (l, enums [i].key);
			lua_pushinteger (l, enums [i].value);
			lua_settable (l, -3);
		}
	}
}

static int loadCompressedTextureFromBuffer (lua_State * l) {
	const char * buffer = NULL;
	size_t bufferLength = 0;
	buffer = lua_tolstring (l, 1, &bufferLength);
	
	GLuint texture = 0;
	Colorado::compressedImageToTexture (buffer, bufferLength, texture);
	
	lua_pushinteger (l, texture);
	return 1;
}

static int loadTextureFromBuffer (lua_State * l) {
	const char * buffer = NULL;
	size_t bufferLength = 0;
	buffer = lua_tolstring (l, 1, &bufferLength);
	
	GLuint texture = SOIL_load_OGL_texture_from_memory (
		(const uchar *)buffer, bufferLength, 
		SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, 
		SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_TEXTURE_REPEATS);
	
	lua_pushinteger (l, texture);
	return 1;
}

static int swapBuffers (lua_State *) {
	Colorado::swapBuffers ();
	return 0;
}

int registerColorado (lua_State * l) {
	luaL_Reg fns [] = {
		{"isKeyPressed", isKeyPressed},
		{"loadCompressedTextureFromBuffer", loadCompressedTextureFromBuffer},
		{"loadTextureFromBuffer", loadTextureFromBuffer},
		{"swapBuffers", swapBuffers},
		{NULL, NULL}
	};
	
	luaL_newlib (l, fns);
	
	bool onPandora = false;
	
#ifdef COLORADO_PANDORA
	onPandora = true;
#endif
	
	lua_pushboolean (l, onPandora);
	lua_setfield (l, -2, "COLORADO_PANDORA");
	
	return 1;
}

}
}
