#include "lua-sdl.h"

#include "lua.hpp"

#include "lua-common.h"

namespace ColoradoLua {

void pushSdlLib (lua_State * l) {
	luaL_Reg sdlFunctions [] = {
		{"Delay", colorado_SDL_Delay},
		{"GetKeyboardState", colorado_SDL_GetKeyboardState},
		{"GetMouseState", colorado_SDL_GetMouseState},
		{"GetTicks", colorado_SDL_GetTicks},
		{"GL_MakeCurrent", colorado_SDL_GL_MakeCurrent},
		{"GL_SwapWindow", colorado_SDL_GL_SwapWindow},
		{"NewSDL_Event", colorado_SDL_Event_new},
		{"PollEvent", colorado_SDL_PollEvent},
		{"RenderClear", colorado_SDL_RenderClear},
		{"RenderPresent", colorado_SDL_RenderPresent},
		{"SetRelativeMouseMode", colorado_SDL_SetRelativeMouseMode},
		{"SetWindowGrab", colorado_SDL_SetWindowGrab},
		{NULL, NULL}
	};
	
	luaL_newlib (l, sdlFunctions);
	
	KeyValueInt enums [] = {
	{"SCANCODE_LEFT", SDL_SCANCODE_LEFT},
	{"SCANCODE_RIGHT", SDL_SCANCODE_RIGHT},
	{"SCANCODE_UP", SDL_SCANCODE_UP},
	{"SCANCODE_DOWN", SDL_SCANCODE_DOWN},
	
	{"SCANCODE_A", SDL_SCANCODE_A},
	{"SCANCODE_D", SDL_SCANCODE_D},
	{"SCANCODE_S", SDL_SCANCODE_S},
	{"SCANCODE_W", SDL_SCANCODE_W},
	{"SCANCODE_SPACE", SDL_SCANCODE_SPACE},
	{"SCANCODE_ESCAPE", SDL_SCANCODE_ESCAPE},
	
	{"MOUSEBUTTONDOWN", SDL_MOUSEBUTTONDOWN},
	{"MOUSEMOTION", SDL_MOUSEMOTION},
	{"KEYDOWN", SDL_KEYDOWN},
	{"QUIT", SDL_QUIT},
	{NULL, 0}
	};
	
	registerInts (l, enums);
}

void registerSDL_EventLib (lua_State * l) {
	luaL_Reg coloradoSdlEventFunctions [] = {
		{"type", colorado_SDL_Event_type},
		{"keyScanCode", colorado_SDL_Event_key_scancode},
		{"keyRepeat", colorado_SDL_Event_key_repeat},
		{"mouseMotionXRel", colorado_SDL_Event_mouseMotion_xrel},
		{"mouseMotionYRel", colorado_SDL_Event_mouseMotion_yrel},
		{NULL, NULL}
	};
	
	luaL_newmetatable (l, "ColoradoSdlEvent");
	luaL_newlib (l, coloradoSdlEventFunctions);
	lua_setfield (l, -2, "__index");
	
	lua_pushstring (l, "__gc");
	lua_pushcfunction (l, colorado_SDL_Event_gc);
	lua_settable (l, -3);
	
	lua_pop (l, 1);
}

int colorado_SDL_Delay (lua_State * l) {
	Uint32 ms = lua_tointeger (l, 1);
	
	SDL_Delay (ms);
	
	return 0;
}

int colorado_SDL_GetKeyboardState (lua_State * l) {
	// This breaks const-correctness
	Uint8 * state = (Uint8 *)SDL_GetKeyboardState (NULL);
	
	lua_pushlightuserdata (l, state);
	return 1;
}

int colorado_SDL_GetMouseState (lua_State * l) {
	int x, y;
	
	Uint32 buttons = SDL_GetMouseState (&x, &y);
	
	lua_pushinteger (l, buttons);
	lua_pushinteger (l, x);
	lua_pushinteger (l, y);
	return 3;
}

int colorado_SDL_GetTicks (lua_State * l) {
	Uint32 ms = SDL_GetTicks ();
	
	lua_pushinteger (l, ms);
	return 1;
}

int colorado_SDL_GL_MakeCurrent (lua_State * l) {
	SDL_Window * window = (SDL_Window *)lua_touserdata (l, 1);
	SDL_GLContext context = lua_touserdata (l, 2);
	
	int rc = SDL_GL_MakeCurrent (window, context);
	lua_pushinteger (l, rc);
	return 1;
}

int colorado_SDL_GL_SwapWindow (lua_State * l) {
	SDL_Window * window = (SDL_Window *)lua_touserdata (l, 1);
	
	SDL_GL_SwapWindow (window);
	return 0;
}

int colorado_SDL_PollEvent (lua_State * l) {
	SDL_Event * event = checkSDL_Event (l, 1);
	
	if (SDL_PollEvent (event)) {
		lua_pushboolean (l, true);
	}
	else {
		lua_pushboolean (l, false);
	}
	
	return 1;
}

int colorado_SDL_RenderClear (lua_State * l) {
	SDL_Renderer * renderer = (SDL_Renderer *)lua_touserdata (l, 1);
	int rc = SDL_RenderClear (renderer);
	lua_pushinteger (l, rc);
	return 1;
}

int colorado_SDL_RenderPresent (lua_State * l) {
	SDL_Renderer * renderer = (SDL_Renderer *)lua_touserdata (l, 1);
	SDL_RenderPresent (renderer);
	return 0;
}

int colorado_SDL_SetRelativeMouseMode (lua_State * l) {
	bool mode = lua_toboolean (l, 1);
	
	int rc = 0;
	if (mode) {
		rc = SDL_SetRelativeMouseMode (SDL_TRUE);
	}
	else {
		rc = SDL_SetRelativeMouseMode (SDL_FALSE);
	}
	lua_pushinteger (l, rc);
	
	return 1;
}

int colorado_SDL_SetWindowGrab (lua_State * l) {
	SDL_Window * window = (SDL_Window *)lua_touserdata (l, 1);
	bool mode = lua_toboolean (l, 2);
	
	if (mode) {
		SDL_SetWindowGrab (window, SDL_TRUE);
	}
	else {
		SDL_SetWindowGrab (window, SDL_FALSE);
	}
	
	return 0;
}

SDL_Event * checkSDL_Event (lua_State * l, int idx) {
	SDL_Event ** userData = (SDL_Event **)luaL_checkudata (l, idx, "ColoradoSdlEvent");
	if (userData == NULL) {
		return NULL;
	}
	else {
		return *userData;
	}
}

void colorado_push_SDL_Event (lua_State * l, SDL_Event * event) {
	SDL_Event ** userData = (SDL_Event **)lua_newuserdata (l, sizeof (SDL_Event *));
	*userData = event;
	luaL_setmetatable (l, "ColoradoSdlEvent");
}

int colorado_SDL_Event_new (lua_State * l) {
	SDL_Event * event = new SDL_Event;
	colorado_push_SDL_Event (l, event);
	
	return 1;
}

int colorado_SDL_Event_gc (lua_State * l) {
	SDL_Event * event = checkSDL_Event (l, 1);
	delete event;
	return 0;
}

int colorado_SDL_Event_type (lua_State * l) {
	SDL_Event * event = checkSDL_Event (l, 1);
	
	lua_pushinteger (l, event->type);
	return 1;
}

int colorado_SDL_Event_key_scancode (lua_State * l) {
	SDL_Event * event = checkSDL_Event (l, 1);
	SDL_Scancode scanCode = event->key.keysym.scancode;
	
	lua_pushinteger (l, scanCode);
	return 1;
}

int colorado_SDL_Event_key_repeat (lua_State * l) {
	SDL_Event * event = checkSDL_Event (l, 1);
	bool repeat = event->key.repeat;
	
	lua_pushboolean (l, repeat);
	return 1;
}

int colorado_SDL_Event_mouseMotion_xrel (lua_State * l) {
	SDL_Event * event = checkSDL_Event (l, 1);
	Sint32 xrel = event->motion.xrel;
	
	lua_pushinteger (l, xrel);
	return 1;
}

int colorado_SDL_Event_mouseMotion_yrel (lua_State * l) {
	SDL_Event * event = checkSDL_Event (l, 1);
	Sint32 yrel = event->motion.yrel;
	
	lua_pushinteger (l, yrel);
	return 1;
}

}
