#include "colorado/lua/lua-ui-vbo-node.h"

#include "lua.hpp"

#include "colorado/lua/shader.h"
#include "colorado/ui-vbo-node.h"

#include "colorado/lua-5.1-helper.h"

namespace Colorado {
namespace Lua {

UiVboNode * toUiVboNode (lua_State * l, int idx) {
	return (UiVboNode *)lua_touserdata (l, idx);
}

static int UiVboNode_new (lua_State * l) {
	UiVboNode * uvn = new UiVboNode;
	
	lua_pushlightuserdata (l, uvn);
	return 1;
}

static int UiVboNode_delete (lua_State * l) {
	UiVboNode * uvn = toUiVboNode (l, 1);
	
	delete uvn;
	return 0;
}

static int UiVboNode_bind (lua_State * l) {
	UiVboNode * uvn = toUiVboNode (l, 1);
	uvn->bind ();
	return 0;
}

static int UiVboNode_clearLayout (lua_State * l) {
	UiVboNode * uvn = toUiVboNode (l, 1);
	uvn->clearLayout ();
	return 0;
}

static int UiVboNode_initializeGl (lua_State * l) {
	UiVboNode * uvn = toUiVboNode (l, 1);
	uvn->initializeGl ();
	return 0;
}

static int UiVboNode_layoutLine (lua_State * l) {
	UiVboNode * uvn = toUiVboNode (l, 1);
	float x = lua_tonumber (l, 2);
	float y = lua_tonumber (l, 3);
	
	const char * stringData = NULL;
	size_t stringLength = 0;
	
	stringData = lua_tolstring (l, 4, &stringLength);
	
	uvn->layoutLine (x, y, stringData, stringLength);
	return 0;
}

static int UiVboNode_prepareVbo (lua_State * l) {
	UiVboNode * uvn = toUiVboNode (l, 1);
	Shader * shader = toShader (l, 2);
	uvn->prepareVbo (*shader);
	return 0;
}

static int UiVboNode_render (lua_State * l) {
	UiVboNode * uvn = toUiVboNode (l, 1);
	uvn->render ();
	return 0;
}

static int UiVboNode_setCapacity (lua_State * l) {
	UiVboNode * uvn = toUiVboNode (l, 1);
	int capacity = lua_tointeger (l, 2);
	uvn->setCapacity (capacity);
	return 0;
}

static int UiVboNode_uploadVbo (lua_State * l) {
	UiVboNode * uvn = toUiVboNode (l, 1);
	uvn->uploadVbo ();
	return 0;
}

int registerUiVboNodeLib (lua_State * l) {
	luaL_Reg fns [] = {
		{"new", UiVboNode_new},
		{"delete", UiVboNode_delete},
		{"bind", UiVboNode_bind},
		{"clearLayout", UiVboNode_clearLayout},
		{"initializeGl", UiVboNode_initializeGl},
		{"layoutLine", UiVboNode_layoutLine},
		{"prepareVbo", UiVboNode_prepareVbo},
		{"render", UiVboNode_render},
		{"setCapacity", UiVboNode_setCapacity},
		{"uploadVbo", UiVboNode_uploadVbo},
		{NULL, NULL}
	};
	
	luaL_newlib (l, fns);
	return 1;
}

}
}
