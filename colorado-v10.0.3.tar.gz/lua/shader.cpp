#include "colorado/lua/shader.h"

#include "glm/glm.hpp"
#include "lua.hpp"

#include "colorado/gl.h"
#include "colorado/gl-shader.h"
#include "colorado/lua/matrix.h"
#include "colorado/lua-5.1-helper.h"

namespace Colorado {
namespace Lua {

Shader * toShader (lua_State * l, int idx) {
	return (Shader *)lua_touserdata (l, idx);
}

void pushProgramLinkResult (lua_State * l, const ProgramLinkResult & plr) {
	/*
	if result.linkSuccess then
		print ("Compiled and linked program from", vertFn, fragFn)
	else
		if not result.vertexCompileSuccess then
			print ("Could not compile vertex shader from", vertFn)
			print (result.vertexInfoLog)
		elseif not result.fragmentCompileSuccess then
			print ("Could not compile fragment shader from", fragFn)
			print (result.fragmentInfoLog)
		else
			print ("Could not link program from", vertFn, fragFn)
			print (result.infoLog)
		end
	end
	*/
	
	lua_newtable (l);
	
	lua_pushboolean (l, plr.linkSuccess);
	lua_setfield (l, -2, "linkSuccess");
	
	lua_pushlstring (l, plr.infoLog.data (), plr.infoLog.size ());
	lua_setfield (l, -2, "infoLog");
	
	// TODO: Add the remaining fields
}

static int Shader_new (lua_State * l) {
	Shader * shader = new Shader;
	
	lua_pushlightuserdata (l, shader);
	return 1;
}

static int Shader_loadFromBuffers (lua_State * l) {
	Shader * shader = toShader (l, 1);
	size_t vertLen = 0;
	size_t fragLen = 0;
	
	const char * vertSource = lua_tolstring (l, 2, &vertLen);
	const char * fragSource = lua_tolstring (l, 3, &fragLen);
	
	ProgramLinkResult rc = shader->loadProgramFromBuffers (vertSource, vertLen, fragSource, fragLen);
	
	lua_newtable (l);
	
	lua_pushlstring (l, rc.infoLog.data (), rc.infoLog.size ());
	lua_setfield (l, -2, "infoLog");
	
	lua_pushboolean (l, rc.linkSuccess);
	lua_setfield (l, -2, "linkSuccess");
	
	return 1;
}

static int Shader_program (lua_State * l) {
	Shader * shader = toShader (l, 1);
	
	lua_pushinteger (l, shader->program);
	return 1;
}

static int Shader_delete (lua_State * l) {
	Shader * shader = toShader (l, 1);
	delete shader;
	return 0;
}

static int Shader_attributeLocation (lua_State * l) {
	Shader * shader = toShader (l, 1);
	const char * name = lua_tostring (l, 2);
	
	GLint attributeLocation = shader->attributeLocation (name);
	lua_pushinteger (l, attributeLocation);
	return 1;
}

static int Shader_bind (lua_State * l) {
	Shader * shader = toShader (l, 1);
	glUseProgram (shader->program);
	return 0;
}

static int Shader_setMatrixUniform (lua_State * l) {
	Shader * shader = toShader (l, 1);
	glm::mat4 * m = toMatrix (l, 2);
	GLint uniform = lua_tointeger (l, 3);
	
	shader->setUniformValueArray (uniform, m, 1);
	return 0;
}

static int Shader_uniformLocation (lua_State * l) {
	Shader * shader = toShader (l, 1);
	const char * name = lua_tostring (l, 2);
	
	GLint uniformLocation = shader->uniformLocation (name);
	lua_pushinteger (l, uniformLocation);
	return 1;
}

void registerShaderLib (lua_State * l) {
	luaL_Reg fns [] = {
		{"new", Shader_new},
		{"delete", Shader_delete},
		{"attributeLocation", Shader_attributeLocation},
		{"bind", Shader_bind},
		{"loadFromBuffers", Shader_loadFromBuffers},
		{"program", Shader_program},
		{"setMatrixUniform", Shader_setMatrixUniform},
		{"uniformLocation", Shader_uniformLocation},
		{NULL, NULL}
	};
	
	luaL_newlib (l, fns);
}

}
}
