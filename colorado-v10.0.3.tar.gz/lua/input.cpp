#include "colorado/lua/input.h"

#include "lua.hpp"
#include <SDL/SDL.h>

#include "colorado/lua/colorado.h"
#include "colorado/lua-5.1-helper.h"

namespace Colorado {
namespace Lua {

static void registerKeyboard (lua_State * ls) {
	lua_newtable (ls);
	KeyValueInt enums [] = {
		{"ESCAPE", SDLK_ESCAPE},
		
		// Arrow keys
		{"LEFT", SDLK_LEFT},
		{"RIGHT", SDLK_RIGHT},
		{"UP", SDLK_UP},
		{"DOWN", SDLK_DOWN},
		
		// Alphabet
		{"a", SDLK_a},
		{"b", SDLK_b},
		{"c", SDLK_c},
		{"d", SDLK_d},
		{"e", SDLK_e},
		{"f", SDLK_f},
		{"g", SDLK_g},
		{"h", SDLK_h},
		{"i", SDLK_i},
		{"j", SDLK_j},
		{"k", SDLK_k},
		{"l", SDLK_l},
		{"m", SDLK_m},
		{"n", SDLK_n},
		{"o", SDLK_o},
		{"p", SDLK_p},
		{"q", SDLK_q},
		{"r", SDLK_r},
		{"s", SDLK_s},
		{"t", SDLK_t},
		{"u", SDLK_u},
		{"v", SDLK_v},
		{"w", SDLK_w},
		{"x", SDLK_x},
		{"y", SDLK_y},
		{"z", SDLK_z},
		
		// Handbrake which is never used
		{"SPACE", SDLK_SPACE},
		
		// Pandora keys
		{"HOME", SDLK_HOME},
		{"END", SDLK_END},
		{"PAGEUP", SDLK_PAGEUP},
		{"PAGEDOWN", SDLK_PAGEDOWN},
		{"LCTRL", SDLK_LCTRL},
		{"RCTRL", SDLK_RCTRL},
		{NULL, 0}
	};
	registerInts (ls, enums);
}

static int GetKeyDown (lua_State * l) {
	Uint8 * keyState = (Uint8 *)lua_touserdata (l, 1);
	int keyIndex = lua_tointeger (l, 2);
	
	bool down = keyState [keyIndex];
	
	lua_pushboolean (l, down);
	return 1;
}

static int GetKeyState (lua_State * l) {
	Uint8 * keyState = SDL_GetKeyState (NULL);
	
	lua_pushlightuserdata (l, keyState);
	
	return 1;
}

static int grabInput (lua_State * l) {
	bool grab = lua_toboolean (l, 1);
	
	if (grab) {
		SDL_WM_GrabInput (SDL_GRAB_ON);
		SDL_ShowCursor (SDL_FALSE);
	}
	else {
		SDL_WM_GrabInput (SDL_GRAB_OFF);
		SDL_ShowCursor (SDL_TRUE);
	}
	
	return 0;
}

static int JoystickClose (lua_State * l) {
	SDL_Joystick * joystick = (SDL_Joystick *)lua_touserdata (l, 1);
	
	SDL_JoystickClose (joystick);
	
	return 0;
}

static int JoystickGetAxis (lua_State * l) {
	SDL_Joystick * joystick = (SDL_Joystick *)lua_touserdata (l, 1);
	int axis = lua_tointeger (l, 2);
	
	int value = SDL_JoystickGetAxis (joystick, axis);
	
	lua_pushinteger (l, value);
	return 1;
}

static int JoystickGetButton (lua_State * l) {
	SDL_Joystick * joystick = (SDL_Joystick *)lua_touserdata (l, 1);
	int button = lua_tointeger (l, 2);
	
	Uint8 down = SDL_JoystickGetButton (joystick, button);
	
	lua_pushboolean (l, down);
	return 1;
}

static int JoystickGetHat (lua_State * l) {
	SDL_Joystick * joystick = (SDL_Joystick *)lua_touserdata (l, 1);
	int hat = lua_tointeger (l, 2);
	
	int value = SDL_JoystickGetHat (joystick, hat);
	
	lua_pushinteger (l, value);
	return 1;
}

static int JoystickName (lua_State * l) {
	int index = lua_tointeger (l, 1);
	
	const char * name = SDL_JoystickName (index);
	
	lua_pushstring (l, name);
	return 1;
}

static int JoystickOpen (lua_State * l) {
	int index = lua_tointeger (l, 1);
	
	SDL_Joystick * joystick = SDL_JoystickOpen (index);
	
	if (joystick == NULL) {
		lua_pushnil (l);
	}
	else {
		lua_pushlightuserdata (l, joystick);
	}
	
	return 1;
}

static int NumJoysticks (lua_State * l) {
	int num = SDL_NumJoysticks ();
	
	lua_pushinteger (l, num);
	return 1;
}

void registerSdlInputLib (lua_State * l) {
	luaL_Reg fns [] = {
		{"close", JoystickClose},
		{"getAxis", JoystickGetAxis},
		{"getButton", JoystickGetButton},
		{"getHat", JoystickGetHat},
		{"getKeyDown", GetKeyDown},
		{"getKeyState", GetKeyState},
		{"grabInput", grabInput},
		{"name", JoystickName},
		{"numJoysticks", NumJoysticks},
		{"open", JoystickOpen},
		{NULL, NULL}
	};
	
	luaL_newlib (l, fns);
	
	registerKeyboard (l);
	
	lua_setfield (l, -2, "Key");
	
	KeyValueInt eventTypes [] = {
		{"JOYAXISMOTION", SDL_JOYAXISMOTION},
		{"JOYBUTTONDOWN", SDL_JOYBUTTONDOWN},
		{"JOYBUTTONUP", SDL_JOYBUTTONUP},
		{"JOYHATMOTION", SDL_JOYHATMOTION},
		{"KEYDOWN", SDL_KEYDOWN},
		{"KEYUP", SDL_KEYUP},
		{"MOUSEBUTTONDOWN", SDL_MOUSEBUTTONDOWN},
		{"MOUSEBUTTONUP", SDL_MOUSEBUTTONUP},
		{"MOUSEMOTION", SDL_MOUSEMOTION},
		{"USER", SDL_USEREVENT},
		{"QUIT", SDL_QUIT},
		{NULL, 0}
	};
	
	lua_newtable (l);
	registerInts (l, eventTypes);
	lua_setfield (l, -2, "EventType");
}

}
}
