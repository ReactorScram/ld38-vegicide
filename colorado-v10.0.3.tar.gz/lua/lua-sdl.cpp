#include "colorado/lua/lua-sdl.h"

#include "lua.hpp"
#include <SDL/SDL.h>

#include "colorado/lua/colorado.h"

#include "colorado/lua-5.1-helper.h"

namespace Colorado {
namespace Lua {

static int delay (lua_State * l) {
	Uint32 ms = lua_tointeger (l, 1);
	
	SDL_Delay (ms);
	
	return 0;
}

static int getMouseState (lua_State * l) {
	int x, y;
	
	Uint32 buttons = SDL_GetMouseState (&x, &y);
	
	lua_pushinteger (l, buttons);
	lua_pushinteger (l, x);
	lua_pushinteger (l, y);
	return 3;
}

static int getTicks (lua_State * l) {
	lua_pushinteger (l, SDL_GetTicks ());
	return 1;
}

static SDL_Event * checkSDL_Event (lua_State * l, int idx) {
	SDL_Event ** userData = (SDL_Event **)luaL_checkudata (l, idx, "ColoradoSdlEvent");
	if (userData == NULL) {
		return NULL;
	}
	else {
		return *userData;
	}
}

static void colorado_push_SDL_Event (lua_State * l, SDL_Event * event) {
	SDL_Event ** userData = (SDL_Event **)lua_newuserdata (l, sizeof (SDL_Event *));
	*userData = event;
	luaL_setmetatable (l, "ColoradoSdlEvent");
}

static int newSDL_Event (lua_State * l) {
	SDL_Event * event = new SDL_Event;
	colorado_push_SDL_Event (l, event);
	
	return 1;
}

static int colorado_SDL_Event_gc (lua_State * l) {
	SDL_Event * event = checkSDL_Event (l, 1);
	delete event;
	return 0;
}

static int colorado_SDL_Event_type (lua_State * l) {
	SDL_Event * event = checkSDL_Event (l, 1);
	
	lua_pushinteger (l, event->type);
	return 1;
}

static int colorado_SDL_Event_key_scancode (lua_State * l) {
	SDL_Event * event = checkSDL_Event (l, 1);
	int scanCode = event->key.keysym.sym;
	
	lua_pushinteger (l, scanCode);
	return 1;
}

static int colorado_SDL_Event_joyAxis_axis (lua_State * l) {
	SDL_Event * event = checkSDL_Event (l, 1);
	
	lua_pushinteger (l, event->jaxis.axis);
	return 1;
}

static int colorado_SDL_Event_joyAxis_value (lua_State * l) {
	SDL_Event * event = checkSDL_Event (l, 1);
	
	lua_pushinteger (l, event->jaxis.value);
	return 1;
}

static int colorado_SDL_Event_joyButton_button (lua_State * l) {
	SDL_Event * event = checkSDL_Event (l, 1);
	
	lua_pushinteger (l, event->jbutton.button);
	return 1;
}

static int colorado_SDL_Event_joyHat_value (lua_State * l) {
	SDL_Event * event = checkSDL_Event (l, 1);
	
	lua_pushinteger (l, event->jhat.value);
	return 1;
}

static int colorado_SDL_Event_mouseMotion_xrel (lua_State * l) {
	SDL_Event * event = checkSDL_Event (l, 1);
	Sint32 xrel = event->motion.xrel;
	
	lua_pushinteger (l, xrel);
	return 1;
}

static int colorado_SDL_Event_mouseMotion_yrel (lua_State * l) {
	SDL_Event * event = checkSDL_Event (l, 1);
	Sint32 yrel = event->motion.yrel;
	
	lua_pushinteger (l, yrel);
	return 1;
}

static int pollEvent (lua_State * l) {
	SDL_Event * event = checkSDL_Event (l, 1);
	
	if (SDL_PollEvent (event)) {
		lua_pushboolean (l, true);
	}
	else {
		lua_pushboolean (l, false);
	}
	
	return 1;
}

static int colorado_SDL_WM_SetCaption (lua_State * l) {
	const char * title = lua_tostring (l, 1);
	SDL_WM_SetCaption (title, NULL);
	
	return 0;
}

int registerSdlLib (lua_State * l) {
	luaL_Reg fns [] = {
		{"delay", delay},
		{"getMouseState", getMouseState},
		{"getTicks", getTicks},
		{"newSDL_Event", newSDL_Event},
		{"pollEvent", pollEvent},
		{"WM_SetCaption", colorado_SDL_WM_SetCaption},
		{NULL, NULL}
	};
	
	luaL_newlib (l, fns);
	
	luaL_Reg coloradoSdlEventFunctions [] = {
		{"type", colorado_SDL_Event_type},
		{"keyScanCode", colorado_SDL_Event_key_scancode},
		{"joyAxisAxis", colorado_SDL_Event_joyAxis_axis},
		{"joyAxisValue", colorado_SDL_Event_joyAxis_value},
		{"joyButtonButton", colorado_SDL_Event_joyButton_button},
		{"joyHatValue", colorado_SDL_Event_joyHat_value},
		{"mouseMotionXRel", colorado_SDL_Event_mouseMotion_xrel},
		{"mouseMotionYRel", colorado_SDL_Event_mouseMotion_yrel},
		{NULL, NULL}
	};
	
	luaL_newmetatable (l, "ColoradoSdlEvent");
	luaL_newlib (l, coloradoSdlEventFunctions);
	lua_setfield (l, -2, "__index");
	
	lua_pushcfunction (l, colorado_SDL_Event_gc);
	lua_setfield (l, -2, "__gc");
	
	lua_pop (l, 1);
	
	
	
	return 1;
}

}
}
