#include "colorado/lua/lua-game.h"

#include "colorado/game.h"
#include "colorado/screen-options.h"

using Colorado::Game;

extern "C" {

SDL_Surface * Colorado_Lua_Game_startSdl (const Colorado_ScreenOptions * so) {
	return Game::startSdl (*so);
}

void Colorado_Lua_Game_stopSdl () {
	Game::stopSdl ();
}

}
