#include "colorado/lua/lua-matrix.h"

#include "lua.hpp"

#include <glm/gtc/matrix_access.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/quaternion.hpp>

using glm::mat4;
using glm::quat;
using glm::vec3;
using glm::vec4;

#include "colorado/lua-5.1-helper.h"

namespace Colorado {
namespace Lua {

mat4 * toMatrix (lua_State * l, int idx) {
	mat4 ** userData = (mat4 **)lua_touserdata (l, idx);
	return *userData;
}

void pushMatrix (lua_State * l, mat4 * m) {
	mat4 ** userData = (mat4 **)lua_newuserdata (l, sizeof (mat4 *));
	*userData = m;
	luaL_setmetatable (l, "ColoradoMatrix");
}

int Matrix_new (lua_State * l) {
	mat4 * m = new mat4 (1.0);
	pushMatrix (l, m);
	
	return 1;
}

quat * toQuat (lua_State * l, int idx) {
	quat ** userData = (quat **)lua_touserdata (l, idx);
	return *userData;
}

void pushQuat (lua_State * l, quat * q) {
	quat ** userData = (quat **)lua_newuserdata (l, sizeof (quat *));
	*userData = q;
	luaL_setmetatable (l, "ColoradoQuat");
}

int Quat_new (lua_State * l) {
	float angle = lua_tonumber (l, 1);
	glm::vec3 v;
	
	for (int i = 0; i < 3; ++i) {
		lua_pushinteger (l, i + 1);
		lua_gettable (l, 2);
		v [i] = lua_tonumber (l, -1);
		lua_pop (l, 1);
	}
	
	quat * q = new quat ();
	*q = glm::rotate (*q, angle, v);
	pushQuat (l, q);
	
	return 1;
}

// This function doesn't seem to work
int Matrix_newFromBasis (lua_State * l) {
	mat4 * m = new mat4 (1.0);
	for (int row = 0; row < 3; ++row) {
		for (int col = 0; col < 3; ++col) {
			lua_pushinteger (l, col + 1);
			lua_gettable (l, row + 1);
			
			glm::column (*m, col)[row] = lua_tonumber (l, -1);
			lua_pop (l, 1);
		}
	}
	pushMatrix (l, m);
	return 1;
}

static int Matrix__gc (lua_State * l) {
	mat4 * m = toMatrix (l, 1);
	delete m;
	return 0;
}

static int Matrix__mul (lua_State * l) {
	mat4 * a = toMatrix (l, 1);
	mat4 * b = toMatrix (l, 2);
	
	mat4 * result = new mat4 (*a * *b);
	pushMatrix (l, result);
	return 1;
}

static int Matrix_frustum (lua_State * l) {
	mat4 * m = toMatrix (l, 1);
	double left, right, top, bottom, near, far;
	left = lua_tonumber (l, 2);
	right = lua_tonumber (l, 3);
	top = lua_tonumber (l, 4);
	bottom = lua_tonumber (l, 5);
	near = lua_tonumber (l, 6);
	far = lua_tonumber (l, 7);
	
	*m = glm::frustum (left, right, top, bottom, near, far);
	return 0;
}

static int Matrix_inverse (lua_State * l) {
	mat4 * m = toMatrix (l, 1);
	
	mat4 * inverse = new mat4 (glm::inverse (*m));
	
	pushMatrix (l, inverse);
	return 1;
}

static int Matrix_map (lua_State * l) {
	mat4 * m = toMatrix (l, 1);
	
	float v [4];
	for (int i = 0; i < 4; ++i) {
		lua_pushinteger (l, i + 1);
		lua_gettable (l, 2);
		v [i] = lua_tonumber (l, -1);
		lua_pop (l, 1);
	}
	
	glm::vec4 vec (v [0], v [1], v[2], v [3]);
	
	vec = *m * vec;
	
	lua_newtable (l);
	
	for (int i = 0; i < 4; ++i) {
		lua_pushinteger (l, i + 1);
		lua_pushnumber (l, vec [i]);
		lua_settable (l, -3);
	}
	return 1;
}

static int Matrix_rotate (lua_State * l) {
	mat4 * m = toMatrix (l, 1);
	float angle, x, y, z;
	angle = lua_tonumber (l, 2);
	x = lua_tonumber (l, 3);
	y = lua_tonumber (l, 4);
	z = lua_tonumber (l, 5);
	
	*m = glm::rotate (*m, angle, glm::vec3 (x, y, z));
	
	return 0;
}

static int Matrix_scale1 (lua_State * l) {
	mat4 * m = toMatrix (l, 1);
	float scale = lua_tonumber (l, 2);
	
	*m = glm::scale (*m, glm::vec3 (scale));
	return 0;
}

static int Matrix_scale3 (lua_State * l) {
	mat4 * m = toMatrix (l, 1);
	float x, y, z;
	x = lua_tonumber (l, 2);
	y = lua_tonumber (l, 3);
	z = lua_tonumber (l, 4);
	
	*m = glm::scale (*m, glm::vec3 (x, y, z));
	return 0;
}

static int Matrix_set (lua_State * l) {
	mat4 * m = toMatrix (l, 1);
	int row = lua_tointeger (l, 2);
	int col = lua_tointeger (l, 3);
	
	float value = lua_tonumber (l, 4);
	
	(*m)[row][col] = value;
	return 0;
}

static int Matrix_translate (lua_State * l) {
	mat4 * m = toMatrix (l, 1);
	float x, y, z;
	x = lua_tonumber (l, 2);
	y = lua_tonumber (l, 3);
	z = lua_tonumber (l, 4);
	
	*m = glm::translate (*m, glm::vec3 (x, y, z));
	return 0;
}

static int Quat__gc (lua_State * l) {
	quat * q = toQuat (l, 1);
	delete q;
	return 0;
}

static int Quat__mul (lua_State * l) {
	quat * a = toQuat (l, 1);
	quat * b = toQuat (l, 2);
	
	quat * result = new quat (*a * *b);
	pushQuat (l, result);
	return 1;
}

static int Quat_get (lua_State * l) {
	quat * q = toQuat (l, 1);
	int index = lua_tointeger (l, 2);
	
	lua_pushnumber (l, (*q) [index]);
	return 1;
}

static int Quat_set (lua_State * l) {
	quat * q = toQuat (l, 1);
	int index = lua_tointeger (l, 2);
	float value = lua_tonumber (l, 3);
	
	(*q)[index] = value;
	return 0;
}

static int Quat_inverse (lua_State * l) {
	quat * q = toQuat (l, 1);
	quat * output = new quat ();
	*output = glm::inverse (*q);
	
	pushQuat (l, output);
	return 1;
}

static int Quat_map (lua_State * l) {
	quat * q = toQuat (l, 1);
	
	vec3 vec;
	
	for (int i = 0; i < 3; ++i) {
		lua_pushinteger (l, i + 1);
		lua_gettable (l, 2);
		vec [i] = lua_tonumber (l, -1);
		lua_pop (l, 1);
	}
	
	vec = glm::rotate (*q, vec);
	
	lua_newtable (l);
	
	for (int i = 0; i < 3; ++i) {
		lua_pushinteger (l, i + 1);
		lua_pushnumber (l, vec [i]);
		lua_settable (l, -3);
	}
	return 1;
}

static int Quat_normalize (lua_State * l) {
	quat * q = toQuat (l, 1);
	quat * output = new quat ();
	
	*output = glm::normalize (*q);
	pushQuat (l, output);
	return 1;
}

static int Quat_toMatrix (lua_State * l) {
	quat * q = toQuat (l, 1);
	
	vec3 x = glm::rotate (*q, vec3 (1.0, 0.0, 0.0));
	vec3 y = glm::rotate (*q, vec3 (0.0, 1.0, 0.0));
	vec3 z = glm::rotate (*q, vec3 (0.0, 0.0, 1.0));
	
	mat4 * m = new mat4 (1.0);
	(*m) [0] = vec4 (x, 0.0);
	(*m) [1] = vec4 (y, 0.0);
	(*m) [2] = vec4 (z, 0.0);
	
	pushMatrix (l, m);
	
	return 1;
}

void registerColoradoMatrix (lua_State * l) {
	luaL_Reg coloradoMatrixFunctions [] = {
		{"frustum", Matrix_frustum},
		{"inverse", Matrix_inverse},
		{"map", Matrix_map},
		{"rotate", Matrix_rotate},
		{"scale1", Matrix_scale1},
		{"scale", Matrix_scale3},
		{"set", Matrix_set},
		{"translate", Matrix_translate},
		{NULL, NULL}
	};
	
	luaL_newmetatable (l, "ColoradoMatrix");
	luaL_newlib (l, coloradoMatrixFunctions);
	lua_setfield (l, -2, "__index");
	
	// For some reason, luaL_newlib won't add the special underscored methods
	lua_pushstring (l, "__gc");
	lua_pushcfunction (l, Matrix__gc);
	lua_settable (l, -3);
	
	lua_pushstring (l, "__mul");
	lua_pushcfunction (l, Matrix__mul);
	lua_settable (l, -3);
	
	lua_pop (l, 1);
	
	// Quaternion class
	luaL_Reg coloradoQuatFunctions [] = {
		{"get", Quat_get},
		{"set", Quat_set},
		{"inverse", Quat_inverse},
		{"map", Quat_map},
		{"normalize", Quat_normalize},
		{"toMatrix", Quat_toMatrix},
		{NULL, NULL}
	};
	
	luaL_newmetatable (l, "ColoradoQuat");
	luaL_newlib (l, coloradoQuatFunctions);
	lua_setfield (l, -2, "__index");
	
	lua_pushstring (l, "__gc");
	lua_pushcfunction (l, Quat__gc);
	lua_settable (l, -3);
	
	lua_pushstring (l, "__mul");
	lua_pushcfunction (l, Quat__mul);
	lua_settable (l, -3);
	
	lua_pop (l, 1);
}

}
}
