#include "mesh.h"
#include <fstream>
#include <sstream>
#include <vector>
using namespace std;

// Load an OBJ file from the filename string

void Mesh::load_obj (string filename) {	
	ifstream obj_file;
	obj_file.open (filename.c_str(), ios_base::in);
	
	vector <GLfloat> vert_vector;
	vector <GLfloat> tex_vector;
	vector <uint32_t> vert_index_vector;
	vector <uint32_t> tex_index_vector;
	
	string line;
	//stringstream line_reader;
	uint32_t line_num = 1;
	while (obj_file.good ()) {
		getline (obj_file, line);
		//printf ("Read: %s\n", line.c_str());
		switch (line [0]) {
			case 'v':
				switch (line [1]) {
					case 't':
						// Texture coordinate
						{ // Texture coord
						stringstream line_reader (line);
						GLfloat temp;
						//line_reader.str (line);
						line_reader.seekg (3, ios_base::beg);
						// Read in the U coord
						line_reader >> temp;
						tex_vector.push_back (temp);
						#ifdef OBJ_PARSE_DEBUG
						printf ("vt ");
						printf ("%f ", temp);
						#endif
						// Skip the space character
						line_reader.seekg (1, ios_base::cur);
						// Read in the V coord
						line_reader >> temp;
						tex_vector.push_back (temp);
						#ifdef OBJ_PARSE_DEBUG
						printf ("%f\n", temp);
						#endif
						}
					break;
					case 'n':
						// Vertex normal
						// TODO: Make it so
						#ifdef OBJ_PARSE_DEBUG
						printf ("vn \n");
						#endif
					break;
					case ' ':
						{ // Vertex
						stringstream line_reader (line);
						GLfloat temp;
						//line_reader.str (line);
						line_reader.seekg (2, ios_base::beg);
						// Read in the X coord
						line_reader >> temp;
						vert_vector.push_back (temp);
						#ifdef OBJ_PARSE_DEBUG
						printf ("v ");
						printf ("%f ", temp);
						#endif
						// Skip the space character
						line_reader.seekg (1, ios_base::cur);
						// Read in the Y coord
						line_reader >> temp;
						vert_vector.push_back (temp);
						#ifdef OBJ_PARSE_DEBUG
						printf ("%f ", temp);
						#endif
						// Skip the space character
						line_reader.seekg (1, ios_base::cur);
						// Read in the Z coord
						line_reader >> temp;
						vert_vector.push_back (temp);
						#ifdef OBJ_PARSE_DEBUG
						printf ("%f\n", temp);
						#endif
						}
					break;
				}
			break;
			case 'f':
				// Polygon
				{
				#ifdef OBJ_PARSE_DEBUG
				printf ("f ");
				#endif
				stringstream line_reader (line);
				uint32_t temp;
				// Skip to 0th vertex
				line_reader.seekg (2, ios_base::beg);
				// Read vert 0
				line_reader >> temp;
				#ifdef OBJ_PARSE_DEBUG
				printf ("%i/", temp - 1);
				#endif
				// Subtract 1 since obj is 1-indexed
				vert_index_vector.push_back (temp - 1);
				// Skip to 0th tex coord
				line_reader.seekg (1, ios_base::cur);
				// Read tex coord 0
				line_reader >> temp;
				if (line_reader.fail()) {
					// No texture coord
					line_reader.clear();
					tex_index_vector.push_back (0);
				}
				else {
					#ifdef OBJ_PARSE_DEBUG
					printf ("%i/", temp - 1);
					#endif
					tex_index_vector.push_back (temp - 1);
				}
				// Skip to the 1st vertex
				while (line_reader.get() != ' ') {
					// This will remove extra stuff (normal)
					// And move to the next vertex index
				}
				#ifdef OBJ_PARSE_DEBUG
				printf (" ");
				#endif
				// Read in the 1th vertex
				line_reader >> temp;
				#ifdef OBJ_PARSE_DEBUG
				printf ("%i/", temp - 1);
				#endif
				vert_index_vector.push_back (temp - 1);
				// Skip to 1th tex coord
				line_reader.seekg (1, ios_base::cur);
				// Read tex coord 1
				line_reader >> temp;
				if (line_reader.fail()) {
					// No texture coord
					line_reader.clear();
					tex_index_vector.push_back (0);
				}
				else {
					#ifdef OBJ_PARSE_DEBUG
					printf ("%i/", temp - 1);
					#endif
					tex_index_vector.push_back (temp - 1);
				}
				// Skip to 2th vertex
				while (line_reader.get() != ' ') {
					
				}
				#ifdef OBJ_PARSE_DEBUG
				printf (" ");
				#endif
				// Read in the 2th vertex
				line_reader >> temp;
				#ifdef OBJ_PARSE_DEBUG
				printf ("%i/", temp - 1);
				#endif
				vert_index_vector.push_back (temp - 1);
				// Move to 2th tex coord
				line_reader.seekg (1, ios_base::cur);
				// Read 2th tex coord
				line_reader >> temp;
				if (line_reader.fail()) {
					// No texture coord
					line_reader.clear();
					tex_index_vector.push_back (0);
				}
				else {
					#ifdef OBJ_PARSE_DEBUG
					printf ("%i/", temp - 1);
					#endif
					tex_index_vector.push_back (temp - 1);
				}
				#ifdef OBJ_PARSE_DEBUG
				printf ("\n");
				#endif
				}
			break;
			default:
				#ifdef OBJ_PARSE_DEBUG
				printf ("Skipping line %i\n", line_num);
				#endif
			break;
		}
		++line_num;
	}
	obj_file.close ();
	#ifdef OBJ_PARSE_DEBUG
	printf ("Done reading file\n");
	#endif
	
	num_verts = vert_index_vector.size();
	num_faces = vert_index_vector.size() / 3;
	
	vert_array = new GLfloat [3 * num_verts];
	for (int i = 0; i < num_verts; ++i) {
		vert_array [3 * i + 0] = vert_vector [3 * vert_index_vector [i] + 0];
		vert_array [3 * i + 1] = vert_vector [3 * vert_index_vector [i] + 1];
		vert_array [3 * i + 2] = vert_vector [3 * vert_index_vector [i] + 2];
	}
	
	// In case we didn't read any texture coordinates, make up a fake one just to hold space
	if (tex_vector.size() == 0) {
		tex_vector.push_back (0.0);
		tex_vector.push_back (0.0);
	}
	tex_coord_array = new GLfloat [2 * num_verts];
	for (int i = 0; i < num_verts; ++i) {
		tex_coord_array [2 * i + 0] = tex_vector [2 * tex_index_vector [i] + 0];
		tex_coord_array [2 * i + 1] = tex_vector [2 * tex_index_vector [i] + 1];
	}
	
	vert_index_array = new uint32_t [3 * num_faces];
	for (int i = 0; i < num_faces * 3; i += 3) {
		vert_index_array [i + 0] = i + 0;
		vert_index_array [i + 1] = i + 1;
		vert_index_array [i + 2] = i + 2;
	}
}
