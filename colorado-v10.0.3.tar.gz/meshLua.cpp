#include "colorado/mesh.h"

#include <lua.hpp>
#include "colorado/lua-5.1-helper.h"

namespace Colorado {
void Mesh::loadMeshLua (lua_State * L, bool debug) {
	loadVerticesLua (L, debug);
	loadFacesLua (L, debug);
}

void Mesh::loadVerticesLua (lua_State * L, bool) {
	lua_pushstring (L, "verts");
	lua_gettable (L, -2);
	
	vertexArray.resize (lua_rawlen (L, -1));
	
	for (unsigned int i = 0; i < vertexArray.size (); i++) {
		// Add 1 because Lua is 1-indexed
		lua_pushinteger (L, i + 1);
		lua_gettable (L, -2);
			for (int j = 0; j < 3; ++j) {
				lua_pushinteger (L, j + 1);
				lua_gettable (L, -2);
					vertexArray [i].pos.element [j] = lua_tonumber (L, -1);
				lua_pop (L, 1);
			}
		lua_pop (L, 1);
	}
	lua_pop (L, 1);
	
	lua_pushstring (L, "normals");
	lua_gettable (L, -2);
	for (unsigned int i = 0; i < numVerts (); i++) {
		VboElement & vertexElement = vertexArray [i];
		
		// Add 1 because Lua is 1-indexed
		lua_pushinteger (L, i + 1);
		lua_gettable (L, -2);
			float n [3];
			
			for (int j = 1; j <= 3; ++j) {
				lua_pushinteger (L, j);
				lua_gettable (L, -2);
				n [j - 1] = lua_tonumber (L, -1);
				lua_pop (L, 1);
			}
			
			glm::vec3 normal (n [0], n [1], n [2]);
			// Normalize the vectors in case somehow Blender doesn't
			normal = glm::normalize (normal);
			
			vertexElement.normal.x = normal.x;
			vertexElement.normal.y = normal.y;
			vertexElement.normal.z = normal.z;
		lua_pop (L, 1);
	}
	lua_pop (L, 1);

	lua_pushstring (L, "texCoords");
	lua_gettable (L, -2);
	if (lua_istable (L, -1)) {
		for (unsigned int i = 0; i < numVerts (); i++) {
			// Add 1 because... you know
			lua_pushinteger (L, i + 1);
			lua_gettable (L, -2);
			if (lua_istable (L, -1)) {
				for (int j = 1; j <= 2; ++j) {
					lua_pushinteger (L, j);
					lua_gettable (L, -2);
					vertexArray [i].textureCoord.element [j - 1] = lua_tonumber (L, -1);
					lua_pop (L, 1);
				}
			}
			lua_pop (L, 1);
		}		
	}
	else {
		// Fill the texture coordinates with 0's
		for (unsigned int i = 0; i < numVerts (); i++) {
			for (int j = 1; j <= 2; ++j) {
				vertexArray [i].textureCoord.element [j - 1] = 0;
			}
		}
	}
	lua_pop (L, 1);
}

void Mesh::loadFacesLua (lua_State * L, bool) {
	lua_pushstring (L, "faces");
	lua_gettable (L, -2);
	
	uint32_t numInputFaces = lua_rawlen (L, -1);
	
	vertIndexArray.clear ();
	
	for (uint32_t i = 0; i < numInputFaces; i++) {
		// Add 1 because Lua is 1-indexed
		lua_pushinteger (L, i + 1);
		lua_gettable (L, -2);
		
		int faceSize = lua_rawlen (L, -1);
		
		uint32_t inputIndices [4];
		
		for (int j = 1; j <= faceSize; ++j) {
			lua_pushinteger (L, j);
			lua_gettable (L, -2);
			inputIndices [j - 1] = (uint32_t)(lua_tointeger (L, -1));
			lua_pop (L, 1);
		}
		
		if (faceSize == 3) {
			vertIndexArray.push_back (inputIndices [0]);
			vertIndexArray.push_back (inputIndices [1]);
			vertIndexArray.push_back (inputIndices [2]);
		}
		else if (faceSize == 4) {
			vertIndexArray.push_back (inputIndices [0]);
			vertIndexArray.push_back (inputIndices [1]);
			vertIndexArray.push_back (inputIndices [2]);
			vertIndexArray.push_back (inputIndices [0]);
			vertIndexArray.push_back (inputIndices [2]);
			vertIndexArray.push_back (inputIndices [3]);
		}
		
		lua_pop (L, 1);
	}
	lua_pop (L, 1);
	
	// NOTE: We don't know how big vertIndexArray will be,
	// since any face can be a triangle or a quad.
	// An improvement to the Lua exporter or a small counter function
	// could fix this, but it's not a big deal.
	
	optimizeTriangleOrder ();
}
}
