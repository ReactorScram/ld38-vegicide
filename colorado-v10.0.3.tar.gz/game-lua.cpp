#include "colorado/game-lua.h"

#include <iostream>
using std::cerr;
using std::cout;
using std::endl;

#include "lua.hpp"

#include <SDL/SDL.h>
#ifdef WIN32
#undef main
#endif

#include "colorado/game.h"
#include "colorado/gl.h"
#include "colorado/lua/colorado.h"
#include "colorado/lua/input.h"
#include "colorado/lua/lua-buffer.h"
#include "colorado/lua/lua-matrix.h"
#include "colorado/lua/lua-sdl.h"
#include "colorado/lua/lua-ui-vbo-node.h"
#include "colorado/lua/shader.h"
#include "colorado/screen-options.h"

#include "terf/terf.h"

namespace Colorado {

class GameLuaPImpl {
public:
	bool initialized;
	std::string coloradoDir;
	lua_State * lua;
	
	GameLuaPImpl (int, char * []);
	
	bool init ();
	void exec ();
	void deinit ();
	
	void getLuaCallback (const char *);
};

GameLua::GameLua (int argc, char * argv []) {
	pImpl = new GameLuaPImpl (argc, argv);
}

GameLua::~GameLua () {
	deinit ();
	delete pImpl;
}

bool GameLua::init () {
	return pImpl->init ();
}

void GameLua::exec () {
	pImpl->exec ();
}

void GameLua::deinit () {
	pImpl->deinit ();
}
/*
int GameLua::main (int argc, char * argv []) {
	Colorado::GameLua view (argc, argv);
	if (view.init ()) {
		view.exec ();
	}
	else {
		return 1;
	}
	
	return 0;
}
*/
GameLuaPImpl::GameLuaPImpl (int /* argc */, char * /* argv */ []) {
	initialized = false;
}

bool GameLuaPImpl::init () {
	lua = luaL_newstate ();
	luaL_openlibs (lua);
	
	// libs table
	luaopen_libcolorado (lua);
	
	lua_setglobal (lua, "libs");
	
	int rc = 0;
	
	Terf::Archive terf ("rom.tar", "rom.tar.index");
	
	std::vector <uint8_t> buffer = terf.lookupFile ("main.lua");
	
	rc = luaL_loadbuffer (lua, (const char *)buffer.data (), buffer.size (), "main.lua");
	if (rc != 0) {
		cerr << "Could not load / compile file main.lua" << endl;
		cerr << lua_tostring (lua, -1) << endl;
		return false;
	}
	
	rc = lua_pcall (lua, 0, 0, 0);
	if (rc != 0) {
		cerr << "Could not run compiled code from main.lua" << endl;
		cerr << lua_tostring (lua, -1) << endl;
		return false;
	}
	
	getLuaCallback ("onInit");
	
	lua_call (lua, 0, 0);
	lua_pop (lua, 1);
	
	return true;
}

void GameLuaPImpl::exec () {
	getLuaCallback ("onExec");
	
	lua_call (lua, 0, 0);
	lua_pop (lua, 1);
}

void GameLuaPImpl::deinit () {
	getLuaCallback ("onExit");
	lua_pcall (lua, 0, 0, 0);
	lua_pop (lua, 1);
	
	lua_close (lua);
}

void GameLuaPImpl::getLuaCallback (const char * name) {
	lua_getglobal (lua, "callbacks");
	lua_getfield (lua, -1, name);
}

extern "C" {

int COLORADO_DLLSPEC luaopen_libcolorado (lua_State * l) {
	lua_newtable (l);
	
	Colorado::Lua::registerBufferLib (l);
	lua_setfield (l, -2, "Buffer");
	
	Colorado::Lua::registerColoradoMatrix (l);
	
	Colorado::Lua::registerColorado (l);
	
		Colorado::Lua::registerShaderLib (l);
		lua_setfield (l, -2, "Shader");
		
		Colorado::Lua::registerUiVboNodeLib (l);
		lua_setfield (l, -2, "UiVboNode");
		
		lua_pushcfunction (l, Colorado::Lua::Matrix_new);
		lua_setfield (l, -2, "newMatrix");
		
		lua_pushcfunction (l, Colorado::Lua::Quat_new);
		lua_setfield (l, -2, "newQuat");
	
	lua_setfield (l, -2, "Colorado");
	/*
	Colorado::Lua::registerGlLib (l);
	lua_setfield (l, -2, "Gl");
	*/
	Colorado::Lua::registerSdlLib (l);
	lua_setfield (l, -2, "Sdl");
	
	Colorado::Lua::registerSdlInputLib (l);
	lua_setfield (l, -2, "SdlInput");
	
	return 1;
}

}

}
